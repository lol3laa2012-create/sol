import random, time, datetime
import discord
from discord import app_commands
from discord.ext import commands, tasks
import config as C
from cogs.economy import get_user


class Levels(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cool = {}
        self.loop.start()

    def cog_unload(self):
        self.loop.cancel()
        self.bot.store.save()

    async def sync_roles(self, member, lvl):
        """يدّي أعلى رتبة ليفل وصلها العضو ويشيل الباقي"""
        want = max([n for n in C.LEVEL_MILESTONES if n <= lvl], default=None)
        names = {C.level_role_name(n): n for n in C.LEVEL_MILESTONES}
        have = [r for r in member.roles if r.name in names]
        target = discord.utils.get(member.guild.roles, name=C.level_role_name(want)) if want else None
        try:
            rm = [r for r in have if r != target]
            if rm: await member.remove_roles(*rm, reason="Level roles")
            if target and target not in member.roles: await member.add_roles(target, reason="Level roles")
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_message(self, m):
        if m.author.bot or not m.guild or m.content.startswith("!"):
            return
        u = get_user(self.bot, m.guild.id, m.author.id)
        u["msgs"] += 1
        if u["msgs"] % C.MSG_COIN_EVERY == 0:
            u["coins"] += 1
        now = time.time()
        if now - self.cool.get((m.guild.id, m.author.id), 0) < 60:
            return
        self.cool[(m.guild.id, m.author.id)] = now
        before = C.level_of(u["xp"])
        u["xp"] += random.randint(15, 25)
        after = C.level_of(u["xp"])
        if after > before:
            reward = after * C.LEVEL_UP_REWARD
            u["coins"] += reward
            await self.sync_roles(m.author, after)
            cfg = self.bot.store.get(m.guild.id)
            ch = m.guild.get_channel(cfg.get("level_channel") or 0) or m.channel
            e = discord.Embed(title="🎉 Level Up!", color=0xE67E22,
                              description=f"Congratulations, **{m.author.display_name}**!\nYou reached level **{after}**.\n🎁 {C.money(reward)}")
            e.set_thumbnail(url=m.author.display_avatar.url)
            await ch.send(content=m.author.mention, embed=e)

    @tasks.loop(minutes=1)
    async def loop(self):
        for g in self.bot.guilds:
            for vc in g.voice_channels:
                real = [x for x in vc.members if not x.bot]
                if len(real) < 2:
                    continue
                for mem in real:
                    if mem.voice.self_deaf or mem.voice.afk:
                        continue
                    u = get_user(self.bot, g.id, mem.id)
                    u["voice_min"] += 1; u["coins"] += C.VOICE_COIN_PER_MIN; u["xp"] += 10
                    b, a = C.level_of(u["xp"] - 10), C.level_of(u["xp"])
                    if a > b:
                        await self.sync_roles(mem, a)
        self.bot.store.save()

    @loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    @app_commands.command(name="rank", description="ليفلك وإحصائياتك")
    async def rank(self, i: discord.Interaction, member: discord.Member = None):
        m = member or i.user
        users = self.bot.store.get(i.guild.id).get("users", {})
        u = get_user(self.bot, i.guild.id, m.id)
        pos = sorted(users, key=lambda k: users[k].get("xp", 0), reverse=True).index(str(m.id)) + 1
        lv = C.level_of(u["xp"]); lo, hi = lv ** 2 * 100, (lv + 1) ** 2 * 100
        pct = int((u["xp"] - lo) / (hi - lo) * 10)
        h, mn = divmod(u["voice_min"], 60)
        e = discord.Embed(title=f"📊 {m.display_name}", color=0x7C5CFF, timestamp=datetime.datetime.utcnow())
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="⭐ الليفل", value=f"**{lv}**", inline=True)
        e.add_field(name="🏆 الترتيب", value=f"#{pos} من {len(users)}", inline=True)
        e.add_field(name="✨ XP", value=f"`{'█' * pct}{'░' * (10 - pct)}` {u['xp'] - lo}/{hi - lo}", inline=False)
        e.add_field(name="🎙️ الفويس", value=f"{h}س {mn}د", inline=True)
        e.add_field(name="💬 الرسائل", value=f"{u['msgs']}", inline=True)
        e.add_field(name="💰 الإجمالي", value=C.money(u["coins"] + u["bank"]), inline=True)
        await i.response.send_message(embed=e)

    @app_commands.command(name="top", description="أعلى 10 ليفل")
    async def top(self, i: discord.Interaction):
        users = self.bot.store.get(i.guild.id).get("users", {})
        top = sorted(users.items(), key=lambda kv: kv[1].get("xp", 0), reverse=True)[:10]
        md = ["🥇", "🥈", "🥉"]
        lines = [f"{md[n] if n < 3 else f'**#{n+1}**'} <@{k}> — Lv **{C.level_of(v.get('xp', 0))}** • {v.get('xp', 0):,} XP" for n, (k, v) in enumerate(top)]
        await i.response.send_message(embed=discord.Embed(title="🏆 متصدرين الليفل", description="\n".join(lines) or "لسه مفيش بيانات.", color=0xF1C40F))

    @app_commands.command(name="levels", description="رتب الليفلات")
    async def levels(self, i: discord.Interaction):
        lines = [f"{C.level_role_name(n)} — يحتاج **{n * n * 100:,}** XP" for n in C.LEVEL_MILESTONES]
        await i.response.send_message(embed=discord.Embed(title="⭐ رتب الليفل", description="\n".join(lines), color=0x7C5CFF), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Levels(bot))
