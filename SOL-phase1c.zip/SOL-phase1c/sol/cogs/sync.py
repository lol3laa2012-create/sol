"""Bridge between the bot and the SOL dashboard (shared SQLite database)."""
import time, datetime
import discord
from discord.ext import commands, tasks
from sol import db, schemas

def fill(text, member, guild):
    return (text.replace("{user}", member.mention).replace("{username}", member.display_name)
                .replace("{server}", guild.name).replace("{count}", str(guild.member_count)))

def build_embed(cfg, member, guild):
    e = discord.Embed(title=fill(cfg["title"], member, guild)[:256], description=fill(cfg["description"], member, guild)[:4000],
                      color=int(cfg["color"].lstrip("#"), 16), timestamp=datetime.datetime.utcnow())
    if cfg.get("show_avatar"): e.set_thumbnail(url=member.display_avatar.url)
    if cfg.get("image_url"): e.set_image(url=cfg["image_url"])   # URL is passed through, so GIFs stay animated
    return e

def snapshot(guild):
    ch = [{"id": str(c.id), "name": c.name, "type": "text"} for c in guild.text_channels] + \
         [{"id": str(c.id), "name": c.name, "type": "voice"} for c in guild.voice_channels] + \
         [{"id": str(c.id), "name": c.name, "type": "category"} for c in guild.categories]
    roles = [{"id": str(r.id), "name": r.name, "managed": r.managed} for r in guild.roles]
    db.upsert_guild(guild.id, guild.name, guild.icon.key if guild.icon else None, guild.member_count or 0, ch, roles)

class Sync(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.loop.start()

    def cog_unload(self): self.loop.cancel()

    @commands.Cog.listener()
    async def on_ready(self):
        db.set_status("started", time.time())
        for g in self.bot.guilds: snapshot(g)

    @commands.Cog.listener()
    async def on_guild_join(self, g): snapshot(g)

    @commands.Cog.listener()
    async def on_guild_remove(self, g): db.conn().execute("UPDATE guilds SET present=0 WHERE guild_id=?", (str(g.id),))

    @commands.Cog.listener()
    async def on_guild_channel_create(self, c): snapshot(c.guild)
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, c): snapshot(c.guild)
    @commands.Cog.listener()
    async def on_guild_role_create(self, r): snapshot(r.guild)
    @commands.Cog.listener()
    async def on_guild_role_delete(self, r): snapshot(r.guild)

    @commands.Cog.listener()
    async def on_member_join(self, m):
        cfg = db.get_settings(m.guild.id, "welcome", schemas.defaults("welcome"))
        await self.send(m.guild, m, cfg)

    @commands.Cog.listener()
    async def on_member_remove(self, m):
        cfg = db.get_settings(m.guild.id, "goodbye", schemas.defaults("goodbye"))
        await self.send(m.guild, m, cfg)

    async def send(self, guild, member, cfg):
        if not cfg["enabled"] or not cfg["channel"]: return False
        ch = guild.get_channel(int(cfg["channel"]))
        if not ch: return False
        view = None
        if cfg.get("button_label") and cfg.get("button_url"):
            view = discord.ui.View(); view.add_item(discord.ui.Button(label=cfg["button_label"][:80], url=cfg["button_url"]))
        try:
            await ch.send(embed=build_embed(cfg, member, guild), view=view)
            return True
        except discord.HTTPException:
            return False

    @tasks.loop(seconds=5)
    async def loop(self):
        db.set_status("heartbeat", time.time())
        for c in db.pending_commands():
            try:
                g = self.bot.get_guild(int(c["guild_id"])) if c["guild_id"] else None
                if c["action"] in ("test_welcome", "test_goodbye") and g:
                    feat = c["action"][5:]
                    member = g.get_member(int(__import__("json").loads(c["payload"])["user_id"])) or g.me
                    ok = await self.send(g, member, {**db.get_settings(g.id, feat, schemas.defaults(feat)), "enabled": True})
                    db.finish_command(c["id"], ok, "sent" if ok else "no channel set or missing permission")
                else:
                    db.finish_command(c["id"], False, "unknown action")
            except Exception as ex:
                db.finish_command(c["id"], False, repr(ex))

    @loop.before_loop
    async def _w(self): await self.bot.wait_until_ready()

async def setup(bot): await bot.add_cog(Sync(bot))
