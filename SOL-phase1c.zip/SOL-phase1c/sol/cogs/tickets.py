import asyncio, re, datetime
import discord
from discord import app_commands
from discord.ext import commands

# (المفتاح, الاسم, الوصف, الإيموجي, اسم الروم)
TYPES = {
    "admin":   ("إداري", "تقديم طلب الانضمام لطاقم الإدارة", "🛡️", "admin"),
    "report":  ("شكوى", "تقديم شكوى", "⚠️", "report"),
    "ask":     ("استفسار", "أي استفسار أو سؤال", "❓", "question"),
    "suggest": ("اقتراح", "تقديم اقتراحات لتطوير السيرفر", "💡", "suggestion"),
    "verify":  ("توثيق بنات", "توثيق لو انتي بنوتة", "✅", "verify"),
}

def meta(ch):
    """يقرأ بيانات التذكرة من توبيك الروم: TicketOwner:ID|Type:..|Number:..|ClaimedBy:.."""
    d = dict(p.split(":", 1) for p in (ch.topic or "").split("|") if ":" in p)
    return d if "TicketOwner" in d else None

def is_staff(member, cfg, guild):
    role = guild.get_role(cfg.get("support_role") or 0)
    p = member.guild_permissions
    return p.administrator or p.manage_channels or (role and role in member.roles)

def emb(title, desc=None, color=0x7C5CFF):
    return discord.Embed(title=title, description=desc, color=color, timestamp=datetime.datetime.utcnow())


class TicketSelect(discord.ui.Select):
    def __init__(self):
        opts = [discord.SelectOption(label=v[0], value=k, description=v[1], emoji=v[2]) for k, v in TYPES.items()]
        super().__init__(placeholder="اختر نوع التذكرة التي تريد فتحها...", options=opts, custom_id="ticket:type")

    async def callback(self, i: discord.Interaction):
        g, cfg = i.guild, i.client.store.get(i.guild.id)
        key = self.values[0]
        name_ar, _, icon, slug = TYPES[key]
        # تذكرة واحدة مفتوحة لكل عضو
        for ch in g.text_channels:
            m = meta(ch)
            if m and m["TicketOwner"] == str(i.user.id):
                await i.message.edit(view=TicketPanel())
                return await i.response.send_message(f"عندك تذكرة مفتوحة بالفعل: {ch.mention}", ephemeral=True)
        cfg["ticket_n"] = cfg.get("ticket_n", 0) + 1
        n = cfg["ticket_n"]
        i.client.store.save()
        role = g.get_role(cfg["support_role"]) if cfg["support_role"] else None
        ow = {
            g.default_role: discord.PermissionOverwrite(view_channel=False),
            i.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True, read_message_history=True),
            g.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }
        if role:
            ow[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        cat = g.get_channel(cfg["ticket_category"]) if cfg["ticket_category"] else None
        ch = await g.create_text_channel(f"{slug}-{n}", category=cat, overwrites=ow,
                                         topic=f"TicketOwner:{i.user.id}|Type:{name_ar}|Number:{n}|ClaimedBy:0")
        e = emb(f"{icon} تذكرة {name_ar} (#{n})",
                f"مرحباً بك {i.user.mention}، يرجى كتابة تفاصيل طلبك وسيقوم الفريق المسؤول بالرد عليك.")
        await ch.send(content=f"{i.user.mention} {role.mention if role else ''}", embed=e, view=TicketControls())
        await i.message.edit(view=TicketPanel())  # يرجع القائمة لوضعها الطبيعي
        await i.response.send_message(f"✅ تم فتح تذكرتك: {ch.mention}", ephemeral=True)


class TicketPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())


class TicketControls(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def _guard(self, i):
        cfg = i.client.store.get(i.guild.id)
        m = meta(i.channel)
        if not m:
            await i.response.send_message("ده مش روم تذكرة.", ephemeral=True)
            return None
        if not is_staff(i.user, cfg, i.guild):
            await i.response.send_message("❌ للإدارة فقط.", ephemeral=True)
            return None
        return m

    @discord.ui.button(label="استلام التذكرة", emoji="🎯", style=discord.ButtonStyle.success, custom_id="ticket:claim")
    async def claim(self, i: discord.Interaction, b: discord.ui.Button):
        m = await self._guard(i)
        if not m: return
        if m["ClaimedBy"] != "0":
            return await i.response.send_message("التذكرة متستلمة بالفعل.", ephemeral=True)
        m["ClaimedBy"] = str(i.user.id)
        await i.channel.edit(topic="|".join(f"{k}:{v}" for k, v in m.items()))
        owner = i.guild.get_member(int(m["TicketOwner"]))
        e = emb("🎯 تم استلام التذكرة", f"مرحباً {owner.mention if owner else ''}، تم استلام تذكرتك بواسطة الإداري {i.user.mention} وسيقوم بمتابعة طلبك الآن.", 0x57F287)
        e.add_field(name="🆔 رقم التذكرة", value=f"#{m['Number']}", inline=False)
        e.add_field(name="👤 صاحب التذكرة", value=owner.mention if owner else "—", inline=False)
        e.add_field(name="🛠️ الإداري المسؤول", value=i.user.mention, inline=False)
        b.disabled = True
        await i.message.edit(view=self)
        await i.response.send_message(embed=e)

    @discord.ui.button(label="إغلاق التذكرة", emoji="🔒", style=discord.ButtonStyle.secondary, custom_id="ticket:close")
    async def close(self, i: discord.Interaction, b: discord.ui.Button):
        m = await self._guard(i)
        if not m: return
        owner = i.guild.get_member(int(m["TicketOwner"]))
        if owner:
            await i.channel.set_permissions(owner, view_channel=False)
        await i.channel.edit(name=f"closed-{m['Number']}")
        await i.response.send_message(embed=emb("🔒 تم إغلاق التذكرة", f"بواسطة {i.user.mention}"))

    @discord.ui.button(label="حذف التذكرة", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id="ticket:delete")
    async def delete(self, i: discord.Interaction, b: discord.ui.Button):
        m = await self._guard(i)
        if not m: return
        await i.response.send_message("🗑️ هيتم حذف التذكرة بعد 5 ثواني...")
        log_id = i.client.store.get(i.guild.id)["log_channel"]
        log = i.guild.get_channel(log_id) if log_id else None
        if log:
            await log.send(embed=emb("🗑️ تذكرة اتحذفت", f"#{m['Number']} ({m['Type']}) بواسطة {i.user.mention}"))
        await asyncio.sleep(5)
        await i.channel.delete()


class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(TicketPanel())
        bot.add_view(TicketControls())

    @app_commands.command(name="ticketpanel", description="ابعت لوحة التذاكر")
    @app_commands.default_permissions(administrator=True)
    async def ticketpanel(self, i: discord.Interaction):
        cfg = self.bot.store.get(i.guild.id)
        e = discord.Embed(title=f"WELCOME TO {i.guild.name.upper()} SUPPORT TICKETS",
                          description="اختر نوع التذكرة من القائمة بالأسفل وسيتم فتح روم خاص بيك.", color=0x7C5CFF)
        if cfg.get("panel_image"):
            e.set_image(url=cfg["panel_image"])
        await i.channel.send(embed=e, view=TicketPanel())
        await i.response.send_message("تم ✅", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Tickets(bot))
