import os, asyncio
import discord
import config as C
from discord import app_commands
from discord.ext import commands

P = discord.Permissions

# (الاسم, اللون, الصلاحيات, معروضة على جنب)  — الإيموجي قدام الاسم في ROLE_ICONS
ROLE_ICONS = {"OWNER": "👑", "CO OWNER": "🔱", "ADMINISTRATOR": "⚡", "MODERATOR": "🛡️",
              "SUPPORT": "🎧", "HELPER": "🤝", "MEMBER": "👤"}
ROLES = [
    ("OWNER",         0xE74C3C, P(administrator=True), True),
    ("CO OWNER",      0xE67E22, P(administrator=True), True),
    ("ADMINISTRATOR", 0x9B59B6, P(manage_guild=True, manage_roles=True, manage_channels=True, manage_messages=True,
                                  kick_members=True, ban_members=True, moderate_members=True, mute_members=True,
                                  deafen_members=True, move_members=True, view_audit_log=True, manage_nicknames=True), True),
    ("MODERATOR",     0x3498DB, P(manage_messages=True, kick_members=True, moderate_members=True, mute_members=True,
                                  deafen_members=True, move_members=True, manage_nicknames=True), True),
    ("SUPPORT",       0x1ABC9C, P(manage_messages=True, moderate_members=True, move_members=True), True),
    ("HELPER",        0x2ECC71, P(manage_messages=True), True),
    ("MEMBER",        0x95A5A6, P(), False),
]
STAFF = ["OWNER", "CO OWNER", "ADMINISTRATOR", "MODERATOR", "SUPPORT", "HELPER"]

def fancy(t):
    """حروف إنجليزي مائلة غامقة زي الصورة (𝒊𝒏𝒇𝒐)"""
    return "".join(chr(0x1D468 + ord(c) - 65) if "A" <= c <= "Z" else chr(0x1D482 + ord(c) - 97) if "a" <= c <= "z" else c for c in t)

# (مفتاح الفئة, إيموجي, [(مفتاح الروم, الاسم المعروض, النوع, الوضع)])
# النوع: text|voice|stage — الوضع: open | ro (قراءة فقط) | staff | hub
# غيّر الاسم المعروض زي ما تحب، والمفتاح (الأول) سيبه زي ما هو.
LAYOUT = [
    ("info", "📌", [("rules", "📜・rules", "text", "ro"), ("welcome", "👋・welcome", "text", "ro"),
                    ("announcement", "📢・announcement", "text", "ro"), ("roles", "🎭・roles", "text", "ro"),
                    ("boost", "💎・boost", "text", "ro"), ("levels", "⭐・levels", "text", "ro"),
                    ("stage", "🎤・stage", "stage", "open")]),
    ("tickets", "🎫", [("tickets", "🎫・tickets", "text", "ro"), ("suggestion", "💡・suggestion", "text", "open")]),
    ("bank", "🏦", [("bank", "🏦・bank", "text", "open"), ("transfers", "💸・transfers", "text", "open"),
                    ("casino", "🎰・casino", "text", "open")]),
    ("chat", "💬", [("chat", "💬・chat", "text", "open"), ("cmd", "⌨️・commands", "text", "open"),
                    ("media", "📸・media", "text", "open")]),
    ("support", "🎧", [("support", "🎧・support", "voice", "open"), ("waiting", "⏳・waiting", "voice", "open")]),
    ("vc temp", "➕", [("hub", "➕・create room", "voice", "hub")]),
    ("voice", "🔊", [("lounge1", "🛋️・lounge 1", "voice", "open"), ("lounge2", "🛋️・lounge 2", "voice", "open"),
                     ("music", "🎵・music", "voice", "open")]),
    ("staff", "🛡️", [("logs", "📋・logs", "text", "staff"), ("staff-chat", "🔒・staff-chat", "text", "staff"),
                     ("staff-voice", "🔊・staff-voice", "voice", "staff")]),
    ("Tickets", "", []),  # الفئة اللي بتتفتح فيها التذاكر (مخفية)
]

def cat_title(key, icon):
    return key if key == "Tickets" else f"━━ {icon} {fancy(key)} ━━"

RULES_TEXT = ("**1.** احترام جميع الأعضاء والإدارة.\n**2.** ممنوع السب والشتم والإهانة.\n"
              "**3.** ممنوع الإعلانات ونشر الروابط بدون إذن.\n**4.** ممنوع السبام والإزعاج في الفويس.\n"
              "**5.** قرارات الإدارة نهائية، ولأي مشكلة افتح تذكرة من روم التذاكر.\n"
              "**6.** 3 تحذيرات = كتم مؤقت.")


class Confirm(discord.ui.View):
    def __init__(self, owner_id):
        super().__init__(timeout=60)
        self.owner_id, self.ok = owner_id, None

    async def interaction_check(self, i):
        return i.user.id == self.owner_id

    @discord.ui.button(label="تأكيد وبناء السيرفر", style=discord.ButtonStyle.danger, emoji="🏗️")
    async def yes(self, i, b):
        self.ok = True
        await i.response.edit_message(content="⏳ جاري البناء... ممكن ياخد دقيقة.", view=None)
        self.stop()

    @discord.ui.button(label="إلغاء", style=discord.ButtonStyle.secondary)
    async def no(self, i, b):
        self.ok = False
        await i.response.edit_message(content="تم الإلغاء.", view=None)
        self.stop()


class AutoSetup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        ch = guild.system_channel or next((c for c in guild.text_channels if c.permissions_for(guild.me).send_messages), None)
        if ch:
            await ch.send(embed=discord.Embed(title="👋 أهلاً! أنا بوت الإدارة",
                          description="اكتب `/autosetup` وأنا هبني السيرفر كله: الرتب والرومات والصلاحيات والتذاكر والفويس المؤقت.",
                          color=0x7C5CFF))

    @app_commands.command(name="autosetup", description="بناء السيرفر كامل: رتب + رومات + صلاحيات + إعدادات البوت")
    @app_commands.default_permissions(administrator=True)
    async def autosetup(self, i: discord.Interaction):
        if i.user.id != i.guild.owner_id and not i.user.guild_permissions.administrator:
            return await i.response.send_message("❌ للأدمن فقط.", ephemeral=True)
        v = Confirm(i.user.id)
        await i.response.send_message(
            "⚠️ هيتعمل في السيرفر: **كل الرتب** (إدارة، ألعاب، ألوان، ليفلات) + **الفئات والرومات** + رولات الريأكشن + البنك والليفل.\n"
            "اللي موجود بنفس الاسم مش هيتكرر ولا هيتمسح أي حاجة قديمة.", view=v, ephemeral=True)
        await v.wait()
        if not v.ok:
            return
        try:
            report = await self.build(i.guild)
            await i.edit_original_response(content=report)
        except discord.Forbidden:
            await i.edit_original_response(content="❌ البوت ناقصه صلاحيات. اديله Administrator وارفع رتبته فوق أي رتبة تانية.")

    async def emojis(self, g):
        """يرفع أيقونات الألعاب من فولدر emojis/ كإيموجيات مخصصة (لو مش موجودة)"""
        out = {}
        for key, _ in C.GAME_ROLES:
            em = discord.utils.get(g.emojis, name=key)
            path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "emojis", f"{key}.png")
            if not em and os.path.exists(path):
                try:
                    with open(path, "rb") as f:
                        em = await g.create_custom_emoji(name=key, image=f.read(), reason="Autosetup")
                except discord.HTTPException:
                    em = None
            out[key] = em or "🎮"
        return out

    async def role(self, g, name, color=0, perms=None, hoist=False):
        return discord.utils.get(g.roles, name=name) or await g.create_role(
            name=name, colour=discord.Colour(color), permissions=perms or P(), hoist=hoist, mentionable=False)

    async def fresh(self, ch):
        async for m in ch.history(limit=10):
            if m.author == ch.guild.me:
                return False
        return True

    async def build(self, g: discord.Guild):
        cfg = self.bot.store.get(g.id)
        roles = {}
        for name, color, perms, hoist in ROLES:
            roles[name] = await self.role(g, f"{ROLE_ICONS[name]} {name}", color, perms, hoist)
        for n, (key, label) in enumerate(C.GAME_ROLES):
            roles["game:" + key] = await self.role(g, label, 0x99AAB5)
        for label, color, _ in C.COLOR_ROLES:
            roles["color:" + label] = await self.role(g, label, color)
        for idx, n in enumerate(C.LEVEL_MILESTONES):
            roles[f"lvl:{n}"] = await self.role(g, C.level_role_name(n), C.level_color(idx))
        staff = [roles[n] for n in STAFF]
        staff_ow = {r: discord.PermissionOverwrite(view_channel=True, send_messages=True, connect=True) for r in staff}
        everyone = g.default_role
        created, cats, chans, hub = 0, {}, {}, None

        for cat_name, icon, items in LAYOUT:
            hidden = cat_name in ("staff", "Tickets")
            cat_ow = {everyone: discord.PermissionOverwrite(view_channel=False), **staff_ow, g.me: discord.PermissionOverwrite(view_channel=True, manage_channels=True)} if hidden else None
            shown = cat_title(cat_name, icon)
            cat = discord.utils.get(g.categories, name=shown)
            if not cat:
                cat = await g.create_category(shown, overwrites=cat_ow or {})
                created += 1
            cats[cat_name] = cat
            for key, name, kind, mode in items:
                ow = {}
                if mode == "ro":
                    ow = {everyone: discord.PermissionOverwrite(send_messages=False, add_reactions=True, create_public_threads=False), **staff_ow}
                elif mode == "staff":
                    ow = {everyone: discord.PermissionOverwrite(view_channel=False), **staff_ow}
                try:
                    if kind == "text":
                        ch = discord.utils.get(g.text_channels, name=name.lower().replace(" ", "-")) or await g.create_text_channel(name, category=cat, overwrites=ow)
                    elif kind == "stage":
                        ch = discord.utils.get(g.stage_channels, name=name) or await g.create_stage_channel(name, category=cat)
                    else:
                        ch = discord.utils.get(g.voice_channels, name=name) or await g.create_voice_channel(name, category=cat, overwrites=ow)
                except discord.HTTPException:
                    continue  # مثلاً الستيج محتاج Community مفعّل
                chans[key] = ch
                if mode == "hub":
                    hub = ch
                created += 1

        cfg.update({
            "log_channel": chans["logs"].id, "welcome_channel": chans["welcome"].id,
            "level_channel": chans["levels"].id, "autorole": roles["MEMBER"].id,
            "hub_channel": hub.id if hub else None, "ticket_category": cats["Tickets"].id,
            "support_role": roles["SUPPORT"].id, "antispam": True,
        })
        self.bot.store.save()

        from cogs.tickets import TicketPanel
        from cogs.reactroles import post_panel
        brand = C.BRAND_LINE.format(name=g.name.upper())
        if await self.fresh(chans["rules"]):
            await chans["rules"].send(embed=discord.Embed(title="📜 قوانين السيرفر", description=RULES_TEXT, color=0x7C5CFF))
        tk = chans["tickets"]
        if await self.fresh(tk):
            await tk.send(embed=discord.Embed(title=f"WELCOME TO {g.name.upper()} SUPPORT TICKETS",
                          description="اختر نوع التذكرة من القائمة بالأسفل وسيتم فتح روم خاص بيك.", color=0x7C5CFF), view=TicketPanel())

        # ── رولات بالريأكشن (زي الصورة بالظبط) ──
        rc = chans["roles"]
        if await self.fresh(rc):
            em = await self.emojis(g)
            await post_panel(self.bot, rc, "🎮 Game Roles | رولز الألعاب",
                "اضغط على الإيموجي الخاص باللعبة للحصول على الرتبة الخاصة بها مع باقي الأعضاء!\n\nلإزالة الرتبة اضغط على الإيموجي مرة أخرى.",
                [(em[k], f"**{label}**", roles["game:" + k]) for k, label in C.GAME_ROLES], brand)
            await post_panel(self.bot, rc, "👑 Color Roles | رولز الألوان", "**REACT TO TAKE THE ROLE**",
                [(e, roles["color:" + n].mention, roles["color:" + n]) for n, _, e in C.COLOR_ROLES], brand, exclusive=True)

        lv = chans["levels"]
        if await self.fresh(lv):
            lines = "\n".join(f"{roles[f'lvl:{n}'].mention} — **{n * n * 100:,}** XP" for n in C.LEVEL_MILESTONES)
            await lv.send(embed=discord.Embed(title="⭐ نظام الليفل", color=0x7C5CFF, description=(
                "كل رسالة وكل دقيقة في الفويس بتجيب XP، وكل ليفل جديد بيدّيك عملات 🎁\n"
                "الرتبة بتتغير تلقائي لما توصل للمرحلة الجديدة.\n\n" + lines + "\n\n`/rank` • `/top` • `/levels`")))
        bk = chans["bank"]
        if await self.fresh(bk):
            await bk.send(embed=discord.Embed(title=f"🏦 بنك {g.name}", color=0x7C5CFF, description=(
                f"العملة: **{C.CURRENCY_NAME}** {C.CURRENCY_EMOJI}\n"
                f"🎁 `/daily` — **{C.money(C.DAILY)}** (+{C.DAILY_STREAK_BONUS} لكل يوم متتالي)\n"
                f"🎉 `/weekly` — **{C.money(C.WEEKLY)}**\n"
                "👛 `/balance` • 🏛️ `/deposit` • 💳 `/withdraw`\n💸 `/pay` • 💰 `/rich` • 🎰 `/slots`")))
        return (f"✅ تم بناء السيرفر!\n• الرتب: {len(roles)} (إدارة + ألعاب + ألوان + {len(C.LEVEL_MILESTONES)} رتبة ليفل)\n"
                f"• الفئات والرومات: {created}\n"
                f"• رولات الريأكشن في {rc.mention} + نظام الليفل والبنك جاهزين.\n"
                f"• ادخل {hub.mention if hub else 'روم الفويس المؤقت'} عشان تجرب الفويس المؤقت.\n"
                "• اسحب رتبة البوت لفوق كل الرتب (عشان يقدر يدّي رتب الليفل والألعاب)، وادّي نفسك رتبة OWNER.")


async def setup(bot):
    await bot.add_cog(AutoSetup(bot))
