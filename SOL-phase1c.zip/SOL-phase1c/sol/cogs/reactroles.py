import discord
from discord.ext import commands
import config as C


def ekey(e):
    """مفتاح موحّد للإيموجي: نص عادي، أو ID للمخصص"""
    if isinstance(e, str):
        return e
    return str(e.id) if getattr(e, "id", None) else e.name


async def post_panel(bot, channel, title, desc, rows, footer, exclusive=False, color=0x7C5CFF):
    """rows = [(emoji, نص السطر, role)] — يبعت الإمبد ويحط الريأكشنز ويسجّلها"""
    lines = "\n".join(f"{e} — {t}" for e, t, _ in rows)
    e = discord.Embed(description=f"{desc}\n\n{lines}\n\n{footer}", color=color)
    e.set_author(name=title)
    msg = await channel.send(embed=e)
    for em, _, _ in rows:
        try:
            await msg.add_reaction(em)
        except discord.HTTPException:
            pass
    rr = bot.store.get(channel.guild.id).setdefault("rr", {})
    rr[str(msg.id)] = {"exclusive": exclusive, "map": {ekey(em): r.id for em, _, r in rows}}
    bot.store.save()
    return msg


class ReactRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def lookup(self, p):
        panel = self.bot.store.get(p.guild_id).get("rr", {}).get(str(p.message_id)) if p.guild_id else None
        if not panel:
            return None, None
        return panel, panel["map"].get(ekey(p.emoji))

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, p):
        if p.member is None or p.member.bot:
            return
        panel, rid = self.lookup(p)
        role = p.member.guild.get_role(rid) if rid else None
        if not role:
            return
        try:
            if panel["exclusive"]:
                others = [r for r in p.member.roles if r.id in panel["map"].values() and r.id != rid]
                if others:
                    await p.member.remove_roles(*others)
                msg = await self.bot.get_channel(p.channel_id).fetch_message(p.message_id)
                for rx in msg.reactions:
                    if ekey(rx.emoji) != ekey(p.emoji):
                        await msg.remove_reaction(rx.emoji, p.member)
            await p.member.add_roles(role, reason="Reaction role")
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, p):
        panel, rid = self.lookup(p)
        g = self.bot.get_guild(p.guild_id) if p.guild_id else None
        m = g.get_member(p.user_id) if g else None
        role = g.get_role(rid) if (g and rid) else None
        if m and role and not m.bot and role in m.roles:
            try:
                await m.remove_roles(role, reason="Reaction role removed")
            except discord.HTTPException:
                pass


async def setup(bot):
    await bot.add_cog(ReactRoles(bot))
