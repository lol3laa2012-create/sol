import discord
from discord import app_commands
from discord.ext import commands

REGIONS = [("تلقائي", None), ("روتردام", "rotterdam"), ("أمريكا", "us-east"), ("البرازيل", "brazil"),
           ("هونج كونج", "hongkong"), ("اليابان", "japan"), ("سنغافورة", "singapore"),
           ("أستراليا", "sydney"), ("الهند", "india"), ("روسيا", "russia"), ("جنوب أفريقيا", "southafrica")]


def owner_id(i):
    return i.client.store.get(i.guild.id)["temp"].get(str(i.channel.id))


async def check(i, owner_only=True):
    """يتأكد إن الروم مؤقت وإن الضاغط هو المالك"""
    oid = owner_id(i)
    if oid is None:
        await i.response.send_message("ده مش روم مؤقت.", ephemeral=True)
        return None
    if owner_only and oid != i.user.id:
        await i.response.send_message("❌ للمالك فقط. لو المالك خرج استخدم Claim.", ephemeral=True)
        return None
    return i.channel


class TextModal(discord.ui.Modal):
    def __init__(self, title, label, apply, max_len=90, numeric=False):
        super().__init__(title=title)
        self.apply, self.numeric = apply, numeric
        self.field = discord.ui.TextInput(label=label, max_length=max_len)
        self.add_item(self.field)

    async def on_submit(self, i):
        v = self.field.value.strip()
        if self.numeric and not (v.isdigit() and 0 <= int(v) <= 99):
            return await i.response.send_message("اكتب رقم من 0 لـ 99.", ephemeral=True)
        await self.apply(i.channel, v)
        await i.response.send_message("✅ تم.", ephemeral=True)


class UserPick(discord.ui.View):
    """قائمة اختيار عضو (مؤقتة) تنفذ action على العضو المختار"""
    def __init__(self, action):
        super().__init__(timeout=60)
        self.action = action
        sel = discord.ui.UserSelect(placeholder="اختر عضو...")
        sel.callback = self.cb
        self.sel = sel
        self.add_item(sel)

    async def cb(self, i: discord.Interaction):
        target = self.sel.values[0]
        await self.action(i, i.channel, target)


async def pick(i, text, action):
    await i.response.send_message(text, view=UserPick(action), ephemeral=True)


class RegionSelect(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
        s = discord.ui.Select(placeholder="اختر المنطقة",
                              options=[discord.SelectOption(label=n, value=v or "auto") for n, v in REGIONS])
        s.callback = self.cb
        self.s = s
        self.add_item(s)

    async def cb(self, i):
        v = self.s.values[0]
        await i.channel.edit(rtc_region=None if v == "auto" else v)
        await i.response.edit_message(content="✅ تم تغيير المنطقة.", view=None)


class VoiceControl(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    # ── الصف 1 ──
    @discord.ui.button(label="Name", emoji="🏷️", custom_id="vc:name", row=0)
    async def name(self, i, b):
        if await check(i):
            async def ap(ch, v): await ch.edit(name=v)
            await i.response.send_modal(TextModal("تغيير اسم الروم", "الاسم الجديد", ap))

    @discord.ui.button(label="Status", emoji="📝", custom_id="vc:status", row=0)
    async def status(self, i, b):
        if await check(i):
            async def ap(ch, v):
                try:
                    await ch.edit(status=v)
                except Exception:
                    await ch.send(f"📝 {v}", delete_after=30)
            await i.response.send_modal(TextModal("حالة الروم", "الحالة", ap, 500))

    @discord.ui.button(label="Limit", emoji="👥", custom_id="vc:limit", row=0)
    async def limit(self, i, b):
        if await check(i):
            async def ap(ch, v): await ch.edit(user_limit=int(v))
            await i.response.send_modal(TextModal("حد الأعضاء (0 = بدون حد)", "العدد", ap, 2, True))

    @discord.ui.button(label="Privacy", emoji="🛡️", custom_id="vc:privacy", row=0)
    async def privacy(self, i, b):
        ch = await check(i)
        if ch:
            ow = ch.overwrites_for(i.guild.default_role)
            locked = ow.connect is False
            await ch.set_permissions(i.guild.default_role, connect=None if locked else False)
            await i.response.send_message("🔓 الروم اتفتح" if locked else "🔒 الروم اتقفل (الـ Trust بس يدخلوا)", ephemeral=True)

    @discord.ui.button(label="Trust", emoji="🤝", custom_id="vc:trust", row=0)
    async def trust(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                await ch.set_permissions(m, connect=True, view_channel=True)
                await inter.response.edit_message(content=f"✅ {m.mention} بقى موثوق", view=None)
            await pick(i, "اختر عضو توثقه:", ac)

    # ── الصف 2 ──
    @discord.ui.button(label="Untrust", emoji="🚫", custom_id="vc:untrust", row=1)
    async def untrust(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                await ch.set_permissions(m, overwrite=None)
                await inter.response.edit_message(content=f"✅ اتشال التوثيق عن {m.mention}", view=None)
            await pick(i, "اختر عضو:", ac)

    @discord.ui.button(label="Invite", emoji="📨", custom_id="vc:invite", row=1)
    async def invite(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                await ch.set_permissions(m, connect=True, view_channel=True)
                link = await ch.create_invite(max_age=3600, max_uses=1)
                try:
                    await m.send(f"📨 {inter.user.display_name} بيدعوك لروم **{ch.name}**\n{link}")
                    msg = f"✅ اتبعتله دعوة {m.mention}"
                except discord.HTTPException:
                    msg = f"✅ اتسمحله يدخل، بس الخاص مقفول: {link}"
                await inter.response.edit_message(content=msg, view=None)
            await pick(i, "اختر عضو تدعوه:", ac)

    @discord.ui.button(label="Kick", emoji="📞", custom_id="vc:kick", row=1)
    async def kick(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                if m in ch.members and m.id != inter.user.id:
                    await m.move_to(None)
                    return await inter.response.edit_message(content=f"✅ اتفصل {m.mention}", view=None)
                await inter.response.edit_message(content="العضو مش في الروم.", view=None)
            await pick(i, "اختر عضو تفصله:", ac)

    @discord.ui.button(label="Region", emoji="🌍", custom_id="vc:region", row=1)
    async def region(self, i, b):
        if await check(i):
            await i.response.send_message("اختر المنطقة:", view=RegionSelect(), ephemeral=True)

    @discord.ui.button(label="Block", emoji="⛔", custom_id="vc:block", row=1)
    async def block(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                await ch.set_permissions(m, connect=False, view_channel=False)
                if m in ch.members:
                    await m.move_to(None)
                await inter.response.edit_message(content=f"⛔ اتحظر {m.mention} من الروم", view=None)
            await pick(i, "اختر عضو تحظره:", ac)

    # ── الصف 3 ──
    @discord.ui.button(label="Unblock", emoji="✅", custom_id="vc:unblock", row=2)
    async def unblock(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                await ch.set_permissions(m, overwrite=None)
                await inter.response.edit_message(content=f"✅ اتفك الحظر عن {m.mention}", view=None)
            await pick(i, "اختر عضو:", ac)

    @discord.ui.button(label="Microphone", emoji="🎙️", custom_id="vc:mic", row=2)
    async def mic(self, i, b):
        ch = await check(i)
        if ch:
            ow = ch.overwrites_for(i.guild.default_role)
            muted = ow.speak is False
            await ch.set_permissions(i.guild.default_role, speak=None if muted else False)
            await i.response.send_message("🎙️ الكل يقدر يتكلم" if muted else "🔇 الكلام اتقفل على الكل (الـ Trust بس)", ephemeral=True)

    @discord.ui.button(label="Claim", emoji="👑", custom_id="vc:claim", row=2)
    async def claim(self, i, b):
        ch = await check(i, owner_only=False)
        if not ch: return
        oid = owner_id(i)
        owner = i.guild.get_member(oid)
        if owner and owner in ch.members:
            return await i.response.send_message("المالك لسه في الروم.", ephemeral=True)
        if i.user not in ch.members:
            return await i.response.send_message("لازم تكون جوه الروم.", ephemeral=True)
        i.client.store.get(i.guild.id)["temp"][str(ch.id)] = i.user.id
        i.client.store.save()
        await i.response.send_message(f"👑 {i.user.mention} بقى مالك الروم.")

    @discord.ui.button(label="Transfer", emoji="🔁", custom_id="vc:transfer", row=2)
    async def transfer(self, i, b):
        if await check(i):
            async def ac(inter, ch, m):
                if m.bot or m not in ch.members:
                    return await inter.response.edit_message(content="لازم العضو يكون جوه الروم.", view=None)
                inter.client.store.get(inter.guild.id)["temp"][str(ch.id)] = m.id
                inter.client.store.save()
                await inter.response.edit_message(content=f"👑 الملكية اتنقلت لـ {m.mention}", view=None)
            await pick(i, "اختر المالك الجديد:", ac)


class Voice(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(VoiceControl())

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        cfg = self.bot.store.get(member.guild.id)
        if after.channel and after.channel.id == cfg["hub_channel"]:
            ch = await member.guild.create_voice_channel(
                member.display_name, category=after.channel.category,
                overwrites={member: discord.PermissionOverwrite(view_channel=True, connect=True)})
            cfg["temp"][str(ch.id)] = member.id
            self.bot.store.save()
            await member.move_to(ch)
            e = discord.Embed(title="Voice Temp Interface", description="تحكم في رومك من الأزرار بالأسفل.", color=0x7C5CFF)
            e.set_footer(text=f"المالك: {member.display_name}")
            try:
                await ch.send(content=member.mention, embed=e, view=VoiceControl())
            except discord.HTTPException:
                pass
        if before.channel and str(before.channel.id) in cfg["temp"] and not before.channel.members:
            cfg["temp"].pop(str(before.channel.id), None)
            self.bot.store.save()
            try:
                await before.channel.delete(reason="Temp voice empty")
            except discord.HTTPException:
                pass


async def setup(bot):
    await bot.add_cog(Voice(bot))
