import random, time
import discord
from discord import app_commands
from discord.ext import commands
import config as C


def get_user(bot, gid, uid):
    users = bot.store.get(gid).setdefault("users", {})
    new = str(uid) not in users
    u = users.setdefault(str(uid), {})
    if "points" in u:                      # ترحيل من النظام القديم
        u["coins"] = u.get("coins", 0) + u.pop("points")
    for k in ("xp", "msgs", "voice_min", "daily", "weekly", "streak", "bank"):
        u.setdefault(k, 0)
    u.setdefault("coins", C.START_BALANCE if new else 0)
    return u


def parse_amount(text, available):
    t = text.strip().lower().replace(",", "")
    if t in ("all", "كل", "الكل"):
        return available
    return int(t) if t.isdigit() else None


def fmt_left(sec):
    d, r = divmod(int(sec), 86400); h, r = divmod(r, 3600)
    return " و ".join(x for x in (f"{d} يوم" if d else "", f"{h} ساعة" if h else "", f"{r // 60} دقيقة") if x)


class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def u(self, i, m=None):
        return get_user(self.bot, i.guild.id, (m or i.user).id)

    @app_commands.command(name="balance", description="رصيدك في المحفظة والبنك")
    async def balance(self, i: discord.Interaction, member: discord.Member = None):
        m = member or i.user
        u = self.u(i, m)
        e = discord.Embed(title=f"🏦 حساب {m.display_name}", color=0x7C5CFF)
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="👛 المحفظة", value=C.money(u["coins"]))
        e.add_field(name="🏛️ البنك", value=C.money(u["bank"]))
        e.add_field(name="💎 الإجمالي", value=C.money(u["coins"] + u["bank"]))
        await i.response.send_message(embed=e)

    @app_commands.command(name="deposit", description="إيداع في البنك (رقم أو all)")
    async def deposit(self, i: discord.Interaction, amount: str):
        u = self.u(i); n = parse_amount(amount, u["coins"])
        if not n or n <= 0 or n > u["coins"]:
            return await i.response.send_message("❌ مبلغ غير صالح أو رصيد المحفظة مش كافي.", ephemeral=True)
        u["coins"] -= n; u["bank"] += n; self.bot.store.save()
        await i.response.send_message(f"🏛️ اتودّع **{C.money(n)}** — البنك: **{C.money(u['bank'])}**")

    @app_commands.command(name="withdraw", description="سحب من البنك (رقم أو all)")
    async def withdraw(self, i: discord.Interaction, amount: str):
        u = self.u(i); n = parse_amount(amount, u["bank"])
        if not n or n <= 0 or n > u["bank"]:
            return await i.response.send_message("❌ مبلغ غير صالح أو رصيد البنك مش كافي.", ephemeral=True)
        u["bank"] -= n; u["coins"] += n; self.bot.store.save()
        await i.response.send_message(f"👛 اتسحب **{C.money(n)}** — المحفظة: **{C.money(u['coins'])}**")

    @app_commands.command(name="daily", description=f"هدية يومية ({C.DAILY} {C.CURRENCY_NAME})")
    async def daily(self, i: discord.Interaction):
        u = self.u(i); now = time.time(); left = 86400 - (now - u["daily"])
        if left > 0:
            return await i.response.send_message(f"⏳ ارجع بعد **{fmt_left(left)}**.", ephemeral=True)
        u["streak"] = u["streak"] + 1 if now - u["daily"] < 172800 else 1
        amt = C.DAILY + C.DAILY_STREAK_BONUS * (min(u["streak"], 7) - 1)
        u["daily"] = now; u["coins"] += amt; self.bot.store.save()
        await i.response.send_message(f"🎁 خدت **{C.money(amt)}** | 🔥 سلسلة: **{u['streak']}** يوم\nرصيدك: **{C.money(u['coins'])}**")

    @app_commands.command(name="weekly", description=f"هدية أسبوعية ({C.WEEKLY} {C.CURRENCY_NAME})")
    async def weekly(self, i: discord.Interaction):
        u = self.u(i); left = 604800 - (time.time() - u["weekly"])
        if left > 0:
            return await i.response.send_message(f"⏳ ارجع بعد **{fmt_left(left)}**.", ephemeral=True)
        u["weekly"] = time.time(); u["coins"] += C.WEEKLY; self.bot.store.save()
        await i.response.send_message(f"🎉 هدية الأسبوع: **{C.money(C.WEEKLY)}**\nرصيدك: **{C.money(u['coins'])}**")

    @app_commands.command(name="pay", description="حوّل عملات لعضو")
    async def pay(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000_000]):
        a, b = self.u(i), self.u(i, member)
        if member.bot or member.id == i.user.id or a["coins"] < amount:
            return await i.response.send_message("❌ مش ينفع (رصيد غير كافي أو عضو غير صالح).", ephemeral=True)
        a["coins"] -= amount; b["coins"] += amount; self.bot.store.save()
        await i.response.send_message(f"💸 {i.user.mention} حوّل **{C.money(amount)}** لـ {member.mention}")

    @app_commands.command(name="rich", description="أغنى 10 أعضاء")
    async def rich(self, i: discord.Interaction):
        users = self.bot.store.get(i.guild.id).get("users", {})
        top = sorted(users.items(), key=lambda kv: kv[1].get("coins", 0) + kv[1].get("bank", 0), reverse=True)[:10]
        md = ["🥇", "🥈", "🥉"]
        lines = [f"{md[n] if n < 3 else f'**#{n+1}**'} <@{k}> — **{C.money(v.get('coins', 0) + v.get('bank', 0))}**" for n, (k, v) in enumerate(top)]
        await i.response.send_message(embed=discord.Embed(title="💰 الأغنى في السيرفر", description="\n".join(lines) or "لسه مفيش بيانات.", color=0xF1C40F))

    @app_commands.command(name="slots", description="لعبة سلوتس (الحد الأدنى 10)")
    async def slots(self, i: discord.Interaction, bet: app_commands.Range[int, 10, 10000]):
        u = self.u(i)
        if u["coins"] < bet:
            return await i.response.send_message("❌ رصيدك مش كافي.", ephemeral=True)
        r = [random.choice(["🍒", "🍋", "🍇", "🔔", "💎"]) for _ in range(3)]
        mult = 5 if r[0] == r[1] == r[2] else 1.5 if len(set(r)) == 2 and random.random() < .35 else 0
        win = int(bet * mult); u["coins"] += win - bet; self.bot.store.save()
        e = discord.Embed(title="🎰 SLOTS" if win else "💥 خسرت", color=0x57F287 if win else 0xED4245,
                          description=f"| {' | '.join(r)} |\n**x{mult}** — {'الربح' if win else 'الخسارة'}: **{C.money(abs(win - bet))}**")
        await i.response.send_message(embed=e)


async def setup(bot):
    await bot.add_cog(Economy(bot))
