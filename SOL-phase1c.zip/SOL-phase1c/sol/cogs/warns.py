import re, time, datetime
import discord
from discord import app_commands
from discord.ext import commands

MAX_WARNS = 3


class WarnDelete(discord.ui.DynamicItem[discord.ui.Button], template=r"warn:del:(?P<uid>[0-9]+)"):
    """زرار حذف تحذير — شغال حتى بعد إعادة تشغيل البوت"""
    def __init__(self, uid: int):
        super().__init__(discord.ui.Button(label="حذف تحذير", style=discord.ButtonStyle.secondary,
                                           emoji="🗑️", custom_id=f"warn:del:{uid}"))
        self.uid = uid

    @classmethod
    async def from_custom_id(cls, interaction, item, match, /):
        return cls(int(match["uid"]))

    async def callback(self, i: discord.Interaction):
        if not i.user.guild_permissions.moderate_members:
            return await i.response.send_message("❌ للإدارة فقط.", ephemeral=True)
        lst = i.client.store.get(i.guild.id)["warns"].get(str(self.uid), [])
        if not lst:
            return await i.response.send_message("مفيش تحذيرات للعضو ده.", ephemeral=True)
        lst.pop()
        i.client.store.save()
        await i.response.send_message(f"✅ اتحذف آخر تحذير من <@{self.uid}> ({len(lst)}/{MAX_WARNS}) بواسطة {i.user.mention}")


def warn_embed(member, count, reason, by):
    e = discord.Embed(title="⚠️ تحذير عضو (Warn)", description="تم إضافة تحذير رسمي للعضو.",
                      color=0xFEE75C, timestamp=datetime.datetime.utcnow())
    e.add_field(name="👤 العضو", value=member.mention)
    e.add_field(name="📊 التحذيرات", value=f"({count}/{MAX_WARNS})")
    e.add_field(name="📝 السبب", value=reason, inline=False)
    e.set_footer(text=f"نظام التحذيرات • بواسطة {by}")
    return e


class Warns(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_dynamic_items(WarnDelete)

    @app_commands.command(name="warn", description="تحذير عضو")
    @app_commands.default_permissions(moderate_members=True)
    async def warn(self, i: discord.Interaction, member: discord.Member, reason: str = "بدون سبب"):
        lst = self.bot.store.get(i.guild.id)["warns"].setdefault(str(member.id), [])
        lst.append({"reason": reason, "by": i.user.id, "at": int(time.time())})
        self.bot.store.save()
        view = discord.ui.View(timeout=None)
        view.add_item(WarnDelete(member.id))
        await i.response.send_message(embed=warn_embed(member, len(lst), reason, i.user.display_name), view=view)
        log_id = self.bot.store.get(i.guild.id)["log_channel"]
        log = i.guild.get_channel(log_id) if log_id else None
        if log:
            await log.send(embed=warn_embed(member, len(lst), reason, i.user.display_name))
        if len(lst) >= MAX_WARNS:
            try:
                await member.timeout(datetime.timedelta(hours=1), reason=f"{MAX_WARNS} warns")
                await i.followup.send(f"🔇 {member.mention} وصل {MAX_WARNS} تحذيرات واتعمله تايم أوت ساعة.")
            except discord.HTTPException:
                pass

    @app_commands.command(name="warnings", description="عرض تحذيرات عضو")
    @app_commands.default_permissions(moderate_members=True)
    async def warnings(self, i: discord.Interaction, member: discord.Member):
        lst = self.bot.store.get(i.guild.id)["warns"].get(str(member.id), [])
        txt = "\n".join(f"**{n+1}.** {w['reason']} — <t:{w['at']}:R>" for n, w in enumerate(lst)) or "مفيش تحذيرات ✅"
        await i.response.send_message(embed=discord.Embed(title=f"تحذيرات {member.display_name} ({len(lst)}/{MAX_WARNS})",
                                                          description=txt, color=0xFEE75C))

    @app_commands.command(name="clearwarns", description="مسح كل تحذيرات عضو")
    @app_commands.default_permissions(moderate_members=True)
    async def clearwarns(self, i: discord.Interaction, member: discord.Member):
        self.bot.store.get(i.guild.id)["warns"].pop(str(member.id), None)
        self.bot.store.save()
        await i.response.send_message(f"✅ اتمسحت تحذيرات {member.mention}")


async def setup(bot):
    await bot.add_cog(Warns(bot))
