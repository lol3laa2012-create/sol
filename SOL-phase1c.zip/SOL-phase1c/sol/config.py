"""كل إعدادات الاقتصاد والليفلات والرولات في مكان واحد — عدّل هنا بس."""
import math

# ── العملة (ثابتة) ──
CURRENCY_NAME = "SOL Coin"
CURRENCY_EMOJI = "🪙"
START_BALANCE = 100          # رصيد البداية
DAILY = 500                  # الهدية اليومية
DAILY_STREAK_BONUS = 50      # زيادة لكل يوم متتالي (لحد 7 أيام)
WEEKLY = 3500                # الهدية الأسبوعية
LEVEL_UP_REWARD = 50         # × رقم الليفل
MSG_COIN_EVERY = 3           # كل كام رسالة = عملة
VOICE_COIN_PER_MIN = 1

def money(n):
    return f"{int(n):,} {CURRENCY_EMOJI}"

# ── الليفلات ──
def level_of(xp):
    return int(math.sqrt(xp / 100))

LEVEL_MILESTONES = [1, 3, 5, 8, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100]

def level_role_name(n):
    return f"⭐ Level {n}"

def level_color(idx):
    """تدرّج من رمادي لأحمر لدهبي"""
    t = idx / (len(LEVEL_MILESTONES) - 1)
    stops = [(0x7F, 0x8C, 0x8D), (0xC0, 0x1B, 0x2E), (0xFF, 0xC3, 0x00)]
    a, b, u = (stops[0], stops[1], t * 2) if t < .5 else (stops[1], stops[2], (t - .5) * 2)
    return (int(a[0] + (b[0] - a[0]) * u) << 16) | (int(a[1] + (b[1] - a[1]) * u) << 8) | int(a[2] + (b[2] - a[2]) * u)

# ── رولات الألعاب (المفتاح = اسم الإيموجي = اسم ملف emojis/*.png) ──
GAME_ROLES = [("gta", "GTA"), ("pubg", "PUBG"), ("freefire", "Free Fire"), ("valorant", "Valorant"),
              ("fortnite", "Fortnite"), ("roblox", "Roblox"), ("minecraft", "Minecraft"),
              ("rocketleague", "Rocket League"), ("lol", "League of Legends"), ("brawlhalla", "Brawlhalla")]

# ── رولات الألوان (الاسم, اللون, إيموجي) ──
COLOR_ROLES = [("Royal Amber", 0xFFB300, "🌟"), ("Electric Sapphire", 0x2F5BFF, "💠"),
               ("Midnight Steel", 0x5B6C8A, "🔘"), ("Silver Eclipse", 0xC0C0C8, "⚪"),
               ("Phantom Shadow", 0x3A3550, "🌑"), ("Blush Petal", 0xFF5FA2, "🌸"),
               ("Crimson Flame", 0xE0143C, "🔥"), ("Emerald Mist", 0x2ECC8F, "🍀"),
               ("Violet Dream", 0x9B59FF, "🔮")]

BRAND_LINE = "⚙ ━━━━━━━━━━ {name} ━━━━━━━━━━ ⚙"
