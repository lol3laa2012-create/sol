"""Interactive .env writer:  python setup.py   (so you never edit files by hand)"""
import getpass, secrets, os
def ask(label, secret=False, default=""):
    v = (getpass.getpass if secret else input)(f"{label}{' ['+default+']' if default else ''}: ").strip()
    return v or default
print("SOL setup — values are written to .env only (never share this file)")
import sys
dom = (sys.argv[sys.argv.index("--url")+1] if "--url" in sys.argv else ask("Your site URL, e.g. https://sol.example.com")).rstrip("/")
vals = {"DISCORD_TOKEN": ask("Bot token", True), "DISCORD_CLIENT_ID": ask("Client ID (OAuth2 page)"),
        "DISCORD_CLIENT_SECRET": ask("Client Secret", True), "DISCORD_REDIRECT_URI": dom + "/callback",
        "BASE_URL": dom, "SECRET_KEY": secrets.token_hex(32), "COOKIE_SECURE": "1" if dom.startswith("https") else "0",
        "PORT": ask("Port", default="8080"), "DATA_DIR": ask("Data folder", default="./data")}
with open(".env", "w") as f: f.write("\n".join(f"{k}={v}" for k, v in vals.items()) + "\n")
os.chmod(".env", 0o600); print("Done. Redirect URL to add in Discord Developer Portal:", vals["DISCORD_REDIRECT_URI"])
