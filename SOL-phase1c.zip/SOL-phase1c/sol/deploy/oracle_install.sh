#!/usr/bin/env bash
# One-shot installer for Ubuntu (Oracle Cloud Always Free). Usage: bash deploy/oracle_install.sh your-name.duckdns.org
set -euo pipefail
DOMAIN="${1:-}"
[ -z "$DOMAIN" ] && { echo "Usage: bash deploy/oracle_install.sh your-name.duckdns.org"; exit 1; }
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"; RUN_USER="$(id -un)"

echo "== 1/6 packages"
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip curl gpg debian-keyring debian-archive-keyring apt-transport-https iptables-persistent
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  sudo apt-get update -y && sudo apt-get install -y caddy
fi

echo "== 2/6 python environment"
cd "$APP_DIR"
python3 -m venv venv
./venv/bin/pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt

echo "== 3/6 configuration (.env)"
if [ ! -f .env ]; then
  echo "Answer the questions below. Your secrets are written ONLY to $APP_DIR/.env"
  ./venv/bin/python setup.py --url "https://$DOMAIN"
fi
[ -f .env ] || { echo "No .env created: run  ./venv/bin/python setup.py  then re-run this script"; exit 1; }

echo "== 4/6 firewall (ports 80/443)"
for p in 80 443; do sudo iptables -C INPUT -p tcp --dport $p -j ACCEPT 2>/dev/null || sudo iptables -I INPUT 5 -p tcp --dport $p -j ACCEPT; done
sudo netfilter-persistent save >/dev/null

echo "== 5/6 HTTPS reverse proxy"
PORT="$(grep -E '^PORT=' .env | cut -d= -f2 || true)"; PORT="${PORT:-8080}"
printf '%s {\n    reverse_proxy 127.0.0.1:%s\n}\n' "$DOMAIN" "$PORT" | sudo tee /etc/caddy/Caddyfile >/dev/null
sudo systemctl enable --now caddy && sudo systemctl reload caddy

echo "== 6/6 service (auto-start + auto-restart)"
sudo tee /etc/systemd/system/sol.service >/dev/null <<UNIT
[Unit]
Description=SOL Discord bot + dashboard
After=network-online.target
[Service]
User=$RUN_USER
WorkingDirectory=$APP_DIR
ExecStart=$APP_DIR/venv/bin/python run.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload && sudo systemctl enable --now sol
sleep 3; systemctl is-active sol && echo "DONE: https://$DOMAIN   (logs: journalctl -u sol -f)"
