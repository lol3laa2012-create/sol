import os, json, re, time, datetime
from collections import defaultdict, deque

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
from sol import db as soldb, schemas as solschemas
from sol.migrate import migrate_settings_json
TOKEN = os.getenv("DISCORD_TOKEN")
# DATA_DIR: فولدر التخزين. على الاستضافة اربطه بـ Volume/Disk عشان البيانات متضيعش مع كل ريستارت.
DATA_DIR = os.getenv("DATA_DIR", ".")
os.makedirs(DATA_DIR, exist_ok=True)
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")

# ───────────────────────── التخزين ─────────────────────────
class Store:
    DEFAULTS = {
        "log_channel": None, "welcome_channel": None, "autorole": None,
        "hub_channel": None, "ticket_category": None, "support_role": None,
        "antilink": False, "antispam": True, "warns": {}, "temp": {},
    }

    def __init__(self):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                self.data = json.load(f)
        except Exception:
            self.data = {}

    def get(self, gid):
        g = self.data.setdefault(str(gid), {})
        for k, v in self.DEFAULTS.items():
            g.setdefault(k, json.loads(json.dumps(v)))
        return g

    def save(self):
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

store = Store()
migrate_settings_json(SETTINGS_FILE)   # one-time import of old SOL data

def gen(gid):
    """per-server general settings from the shared SOL database (editable from the dashboard)"""
    return soldb.get_settings(gid, "general", solschemas.defaults("general"))

# ───────────────────────── البوت ─────────────────────────
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)
bot.store = store

def embed(title, desc=None, color=0x5865F2):
    e = discord.Embed(title=title, description=desc, color=color,
                      timestamp=datetime.datetime.utcnow())
    return e

async def send_log(guild, e):
    ch_id = int(gen(guild.id)["log_channel"] or 0) or store.get(guild.id)["log_channel"]
    ch = guild.get_channel(ch_id) if ch_id else None
    if ch:
        try:
            await ch.send(embed=e)
        except discord.HTTPException:
            pass

# ───────────────────────── الأحداث ─────────────────────────
@bot.event
async def setup_hook():
    for ext in ("sync", "tickets", "voice", "warns", "economy", "levels", "reactroles", "autosetup"):
        await bot.load_extension(f"cogs.{ext}")
    await bot.tree.sync()

@bot.event
async def on_ready():
    print(f"✅ شغال باسم {bot.user} | السيرفرات: {len(bot.guilds)}")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="السيرفر 👀"))

@bot.event
async def on_member_join(member):
    g = gen(member.guild.id)
    ar = int(g["autorole"] or 0) or store.get(member.guild.id)["autorole"]
    if ar:
        role = member.guild.get_role(ar)
        if role:
            try:
                await member.add_roles(role, reason="Autorole")
            except discord.HTTPException:
                pass
    await send_log(member.guild, embed("📥 دخل السيرفر", f"{member} (`{member.id}`)", 0x57F287))

@bot.event
async def on_member_remove(member):
    await send_log(member.guild, embed("📤 خرج من السيرفر", f"{member} (`{member.id}`)", 0xED4245))

@bot.event
async def on_message_delete(m):
    if m.guild and not m.author.bot:
        await send_log(m.guild, embed("🗑️ رسالة اتمسحت",
                       f"**الكاتب:** {m.author.mention}\n**الروم:** {m.channel.mention}\n**المحتوى:** {m.content[:1000] or '—'}", 0xFEE75C))

@bot.event
async def on_message_edit(b, a):
    if a.guild and not a.author.bot and b.content != a.content:
        await send_log(a.guild, embed("✏️ رسالة اتعدلت",
                       f"**الكاتب:** {a.author.mention} في {a.channel.mention}\n**قبل:** {b.content[:500]}\n**بعد:** {a.content[:500]}", 0xFEE75C))

# ── الحماية التلقائية (Anti-link / Anti-spam) ──
LINK_RE = re.compile(r"(https?://|discord\.gg/|www\.)", re.I)
spam_track = defaultdict(lambda: deque(maxlen=6))

@bot.event
async def on_message(m):
    if m.author.bot or not m.guild:
        return
    cfg = gen(m.guild.id)
    is_mod = m.author.guild_permissions.manage_messages
    if cfg["antilink"] and not is_mod and LINK_RE.search(m.content):
        await m.delete()
        return await m.channel.send(f"{m.author.mention} ممنوع اللينكات هنا ⛔", delete_after=5)
    if cfg["antispam"] and not is_mod:
        q = spam_track[(m.guild.id, m.author.id)]
        now = time.time()
        q.append(now)
        if len(q) >= 5 and now - q[0] < 5:
            q.clear()
            try:
                await m.author.timeout(datetime.timedelta(minutes=5), reason="Spam")
                await m.channel.send(f"{m.author.mention} اتعمله تايم أوت 5 دقايق بسبب السبام 🚫", delete_after=8)
                await send_log(m.guild, embed("🚫 سبام", f"{m.author.mention} اتعمله timeout", 0xED4245))
            except discord.HTTPException:
                pass
    await bot.process_commands(m)

# ───────────────────────── الإعدادات ─────────────────────────
@bot.tree.command(name="setup", description="إعداد البوت للسيرفر")
@app_commands.default_permissions(administrator=True)
async def setup(i: discord.Interaction,
                log_channel: discord.TextChannel = None,
                welcome_channel: discord.TextChannel = None,
                autorole: discord.Role = None,
                hub_voice: discord.VoiceChannel = None,
                ticket_category: discord.CategoryChannel = None,
                support_role: discord.Role = None,
                panel_image: str = None,
                antilink: bool = None,
                antispam: bool = None):
    cfg = store.get(i.guild.id)
    for k, v in {"log_channel": log_channel, "welcome_channel": welcome_channel, "autorole": autorole,
                 "hub_channel": hub_voice, "ticket_category": ticket_category, "support_role": support_role}.items():
        if v is not None:
            cfg[k] = v.id
    if panel_image: cfg["panel_image"] = panel_image
    if antilink is not None: cfg["antilink"] = antilink
    if antispam is not None: cfg["antispam"] = antispam
    g = gen(i.guild.id)
    for k, v in (("log_channel", log_channel), ("autorole", autorole)):
        if v is not None: g[k] = str(v.id)
    if antilink is not None: g["antilink"] = antilink
    if antispam is not None: g["antispam"] = antispam
    soldb.save_settings(i.guild.id, "general", g)
    if welcome_channel is not None:
        w = soldb.get_settings(i.guild.id, "welcome", solschemas.defaults("welcome")); w.update(enabled=True, channel=str(welcome_channel.id))
        soldb.save_settings(i.guild.id, "welcome", w)
    store.save()
    await i.response.send_message("✅ تم حفظ الإعدادات.", ephemeral=True)

# ───────────────────────── الإدارة ─────────────────────────
@bot.tree.command(name="kick", description="طرد عضو")
@app_commands.default_permissions(kick_members=True)
async def kick(i: discord.Interaction, member: discord.Member, reason: str = "بدون سبب"):
    await member.kick(reason=reason)
    await i.response.send_message(f"👢 تم طرد {member} | {reason}")
    await send_log(i.guild, embed("👢 Kick", f"{member} بواسطة {i.user}\n{reason}", 0xED4245))

@bot.tree.command(name="ban", description="حظر عضو")
@app_commands.default_permissions(ban_members=True)
async def ban(i: discord.Interaction, member: discord.Member, reason: str = "بدون سبب"):
    await member.ban(reason=reason)
    await i.response.send_message(f"🔨 تم حظر {member} | {reason}")
    await send_log(i.guild, embed("🔨 Ban", f"{member} بواسطة {i.user}\n{reason}", 0xED4245))

@bot.tree.command(name="unban", description="فك حظر بالـ ID")
@app_commands.default_permissions(ban_members=True)
async def unban(i: discord.Interaction, user_id: str):
    await i.guild.unban(discord.Object(id=int(user_id)))
    await i.response.send_message("✅ تم فك الحظر.")

@bot.tree.command(name="timeout", description="تايم أوت لعضو (بالدقايق)")
@app_commands.default_permissions(moderate_members=True)
async def timeout(i: discord.Interaction, member: discord.Member, minutes: int, reason: str = "بدون سبب"):
    await member.timeout(datetime.timedelta(minutes=minutes), reason=reason)
    await i.response.send_message(f"⏳ {member.mention} تايم أوت {minutes} دقيقة")

@bot.tree.command(name="untimeout", description="فك التايم أوت")
@app_commands.default_permissions(moderate_members=True)
async def untimeout(i: discord.Interaction, member: discord.Member):
    await member.timeout(None)
    await i.response.send_message(f"✅ تم فك التايم أوت عن {member.mention}")

@bot.tree.command(name="clear", description="مسح رسايل")
@app_commands.default_permissions(manage_messages=True)
async def clear(i: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    await i.response.defer(ephemeral=True)
    d = await i.channel.purge(limit=amount)
    await i.followup.send(f"🧹 اتمسح {len(d)} رسالة.", ephemeral=True)

@bot.tree.command(name="slowmode", description="سلو مود (ثواني، 0 للإلغاء)")
@app_commands.default_permissions(manage_channels=True)
async def slowmode(i: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]):
    await i.channel.edit(slowmode_delay=seconds)
    await i.response.send_message(f"🐌 السلو مود: {seconds} ثانية")

@bot.tree.command(name="lock", description="قفل الروم")
@app_commands.default_permissions(manage_channels=True)
async def lock(i: discord.Interaction):
    await i.channel.set_permissions(i.guild.default_role, send_messages=False)
    await i.response.send_message("🔒 تم قفل الروم.")

@bot.tree.command(name="unlock", description="فتح الروم")
@app_commands.default_permissions(manage_channels=True)
async def unlock(i: discord.Interaction):
    await i.channel.set_permissions(i.guild.default_role, send_messages=None)
    await i.response.send_message("🔓 تم فتح الروم.")

@bot.tree.command(name="role", description="إضافة/إزالة رتبة من عضو")
@app_commands.default_permissions(manage_roles=True)
async def role(i: discord.Interaction, member: discord.Member, role: discord.Role):
    if role in member.roles:
        await member.remove_roles(role)
        await i.response.send_message(f"➖ اتشالت {role.mention} من {member.mention}")
    else:
        await member.add_roles(role)
        await i.response.send_message(f"➕ اتضافت {role.mention} لـ {member.mention}")

# ───────────────────────── إدارة الفويس ─────────────────────────
def need_voice(m): return m.voice and m.voice.channel

@bot.tree.command(name="vmute", description="ميوت عضو في الفويس")
@app_commands.default_permissions(mute_members=True)
async def vmute(i: discord.Interaction, member: discord.Member):
    await member.edit(mute=True); await i.response.send_message(f"🔇 {member.mention}")

@bot.tree.command(name="vunmute", description="فك ميوت الفويس")
@app_commands.default_permissions(mute_members=True)
async def vunmute(i: discord.Interaction, member: discord.Member):
    await member.edit(mute=False); await i.response.send_message(f"🔊 {member.mention}")

@bot.tree.command(name="vdeafen", description="ديفن عضو في الفويس")
@app_commands.default_permissions(deafen_members=True)
async def vdeafen(i: discord.Interaction, member: discord.Member):
    await member.edit(deafen=True); await i.response.send_message(f"🙉 {member.mention}")

@bot.tree.command(name="vundeafen", description="فك الديفن")
@app_commands.default_permissions(deafen_members=True)
async def vundeafen(i: discord.Interaction, member: discord.Member):
    await member.edit(deafen=False); await i.response.send_message(f"👂 {member.mention}")

@bot.tree.command(name="vkick", description="فصل عضو من الفويس")
@app_commands.default_permissions(move_members=True)
async def vkick(i: discord.Interaction, member: discord.Member):
    await member.move_to(None); await i.response.send_message(f"📴 اتفصل {member.mention}")

@bot.tree.command(name="vmove", description="نقل عضو لروم فويس تاني")
@app_commands.default_permissions(move_members=True)
async def vmove(i: discord.Interaction, member: discord.Member, channel: discord.VoiceChannel):
    await member.move_to(channel); await i.response.send_message(f"➡️ {member.mention} → {channel.mention}")

@bot.tree.command(name="vmoveall", description="نقل كل اللي في روم لروم تاني")
@app_commands.default_permissions(move_members=True)
async def vmoveall(i: discord.Interaction, source: discord.VoiceChannel, target: discord.VoiceChannel):
    n = 0
    for m in list(source.members):
        await m.move_to(target); n += 1
    await i.response.send_message(f"✅ اتنقل {n} عضو.")

@bot.tree.command(name="vmuteall", description="ميوت كل اللي في روم الفويس بتاعك")
@app_commands.default_permissions(mute_members=True)
async def vmuteall(i: discord.Interaction, unmute: bool = False):
    if not need_voice(i.user):
        return await i.response.send_message("لازم تكون في روم فويس.", ephemeral=True)
    for m in i.user.voice.channel.members:
        if m != i.user:
            await m.edit(mute=not unmute)
    await i.response.send_message("تم ✅")

# ───────────────────────── أوامر عامة ─────────────────────────
@bot.tree.command(name="ping", description="سرعة البوت")
async def ping(i: discord.Interaction):
    await i.response.send_message(f"🏓 {round(bot.latency*1000)}ms")

@bot.tree.command(name="avatar", description="صورة عضو")
async def avatar(i: discord.Interaction, member: discord.Member = None):
    member = member or i.user
    e = embed(f"صورة {member}"); e.set_image(url=member.display_avatar.url)
    await i.response.send_message(embed=e)

@bot.tree.command(name="userinfo", description="معلومات عضو")
async def userinfo(i: discord.Interaction, member: discord.Member = None):
    m = member or i.user
    e = embed(str(m))
    e.set_thumbnail(url=m.display_avatar.url)
    e.add_field(name="ID", value=m.id)
    e.add_field(name="انضم للسيرفر", value=discord.utils.format_dt(m.joined_at, "R"))
    e.add_field(name="أنشأ الحساب", value=discord.utils.format_dt(m.created_at, "R"))
    e.add_field(name="أعلى رتبة", value=m.top_role.mention)
    await i.response.send_message(embed=e)

@bot.tree.command(name="serverinfo", description="معلومات السيرفر")
async def serverinfo(i: discord.Interaction):
    g = i.guild
    e = embed(g.name)
    if g.icon: e.set_thumbnail(url=g.icon.url)
    e.add_field(name="الأعضاء", value=g.member_count)
    e.add_field(name="الرومات", value=len(g.channels))
    e.add_field(name="الرتب", value=len(g.roles))
    e.add_field(name="المالك", value=g.owner.mention if g.owner else "—")
    e.add_field(name="اتعمل", value=discord.utils.format_dt(g.created_at, "R"))
    await i.response.send_message(embed=e)

@bot.tree.error
async def on_error(i: discord.Interaction, err: app_commands.AppCommandError):
    msg = "❌ مش معاك صلاحية." if isinstance(err, app_commands.MissingPermissions) else f"❌ حصل خطأ: {err}"
    if i.response.is_done():
        await i.followup.send(msg, ephemeral=True)
    else:
        await i.response.send_message(msg, ephemeral=True)

if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("حط DISCORD_TOKEN في ملف .env")
    bot.run(TOKEN)
