import os, sys, tempfile, time, json
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
tmp = tempfile.mkdtemp()
os.environ.update(SOL_DB=os.path.join(tmp, "t.db"), SECRET_KEY="x"*32, COOKIE_SECURE="0",
                  DISCORD_CLIENT_ID="1", DISCORD_CLIENT_SECRET="s", DISCORD_REDIRECT_URI="http://localhost/callback")
from sol import db
db.DB_PATH = os.environ["SOL_DB"]
from dashboard import app as appmod, discord_api as dapi

A, B, C = "111111111111111111", "222222222222222222", "333333333333333333"
dapi.exchange_code = lambda code: "tok"
dapi.fetch_user = lambda t: {"id": "999", "username": "bob"}
dapi.fetch_guilds = lambda t: [{"id": A, "name": "A", "permissions": 8}, {"id": B, "name": "B", "permissions": 0},
                               {"id": C, "name": "C", "permissions": 0x20}]
for gid, n in ((A, "A"), (B, "B"), (C, "C")):
    db.upsert_guild(gid, n, None, 10, [{"id": "5"+gid[1:], "name": "gen", "type": "text"}], [{"id": "6"+gid[1:], "name": "mod"}])
CH_A, CH_B = "5"+A[1:], "5"+B[1:]

app = appmod.create_app(); app.config["TESTING"] = True
cl = app.test_client()
def login(c):
    r = c.get("/login"); assert r.status_code == 302 and "oauth2/authorize" in r.location
    with c.session_transaction() as s: st = s["state"]
    assert c.get("/callback?code=abc&state=bad").status_code == 400
    assert c.get(f"/callback?code=abc&state={st}").status_code == 302
    with c.session_transaction() as s: return s["csrf"]
def post(c, url, body, csrf): return c.post(url, json=body, headers={"X-CSRF": csrf})

# 1 anonymous blocked
assert cl.get(f"/g/{A}").status_code == 302 and cl.get(f"/api/g/{A}/settings/welcome").status_code == 302
csrf = login(cl)
# 2 server list only shows manageable guilds
html = cl.get("/servers").get_data(as_text=True); assert ">A<" not in html or True
assert "<b>A</b>" in html and "<b>C</b>" in html and "<b>B</b>" not in html
# 3 forbidden guild
assert cl.get(f"/g/{B}").status_code == 403 and cl.get(f"/g/{B}/welcome").status_code == 403
assert post(cl, f"/api/g/{B}/settings/welcome", {"enabled": True}, csrf).status_code == 403
# 4 CSRF
assert cl.post(f"/api/g/{A}/settings/welcome", json={"enabled": True}).status_code == 403
# 5 save + persistence + isolation (A and C both manageable by this user)
r = post(cl, f"/api/g/{A}/settings/welcome", {"enabled": True, "title": "Hello A", "channel": CH_A, "color": "#112233"}, csrf)
assert r.status_code == 200, r.data
r = post(cl, f"/api/g/{C}/settings/welcome", {"title": "Hello C"}, csrf); assert r.status_code == 200
assert db.get_settings(A, "welcome", {})["title"] == "Hello A" and db.get_settings(C, "welcome", {})["title"] == "Hello C"
assert db.get_settings(C, "welcome", {"enabled": False})["enabled"] is False   # C untouched by A's change
# 6 validation
assert post(cl, f"/api/g/{A}/settings/welcome", {"color": "red"}, csrf).status_code == 400
assert post(cl, f"/api/g/{A}/settings/welcome", {"hack": 1}, csrf).status_code == 400
assert post(cl, f"/api/g/{A}/settings/welcome", {"image_url": "javascript:alert(1)"}, csrf).status_code == 400
assert post(cl, f"/api/g/{A}/settings/welcome", {"channel": CH_B}, csrf).status_code == 400   # channel of another guild
# 7 persistence across "restart": new app + new connection
db._local.__dict__.clear(); app2 = appmod.create_app(); c2 = app2.test_client(); login(c2)
assert c2.get(f"/api/g/{A}/settings/welcome").get_json()["title"] == "Hello A"
# 8 test message queue + pages render in both languages
assert post(cl, f"/api/g/{A}/test/welcome", {}, csrf).get_json()["ok"]
assert db.pending_commands()[0]["action"] == "test_welcome"
for f in ("general", "welcome", "goodbye"):
    for lang in ("ar", "en"):
        r = cl.get(f"/g/{A}/{f}?lang={lang}"); assert r.status_code == 200, (f, lang)
assert 'dir="rtl"' in cl.get(f"/g/{A}?lang=ar").get_data(as_text=True)
assert 'dir="ltr"' in cl.get(f"/g/{A}?lang=en").get_data(as_text=True)
# 9 rate limit
codes = [cl.get("/healthz").status_code for _ in range(130)]; assert 429 in codes
print("ALL DASHBOARD TESTS PASSED")

# ---- uploads (fresh app: previous test exhausted the rate limit on purpose) ----
app3 = appmod.create_app(); cl = app3.test_client(); csrf = login(cl)
import io
gif = b"GIF89a" + b"\x01\x00\x01\x00" + os.urandom(200)
def up(c, gid, data, name="a.gif", csrf=None):
    return c.post(f"/api/g/{gid}/upload", data={"file": (io.BytesIO(data), name)}, headers={"X-CSRF": csrf}, content_type="multipart/form-data")
r = up(cl, A, gif, csrf=csrf); j = r.get_json(); assert r.status_code == 200 and j["url"].endswith(".gif"), r.data
got = cl.get(j["url"].replace("http://localhost", "")); assert got.status_code == 200 and got.data == gif   # bytes identical => animation preserved
assert up(cl, A, b"<script>alert(1)</script>", "x.gif", csrf).status_code == 400      # fake extension rejected
assert up(cl, B, gif, csrf=csrf).status_code == 403                                  # no access to other server
assert up(cl, A, gif, csrf=None).status_code == 403                                  # CSRF
assert up(cl, A, b"GIF89a" + b"0" * (9 * 1024 * 1024), csrf=csrf).status_code in (413,)
assert cl.get(f"/media/{A}/../../etc/passwd").status_code == 404
print("UPLOAD TESTS PASSED")
