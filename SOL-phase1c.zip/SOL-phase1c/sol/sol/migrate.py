"""One-time import of the old VEXIA settings.json into the SOL database (non-destructive, idempotent)."""
import json, os
from sol import db, schemas

def migrate_settings_json(path):
    if not os.path.exists(path): return 0
    with open(path, encoding="utf-8") as f: data = json.load(f)
    n = 0
    for gid, cfg in data.items():
        if db.conn().execute("SELECT 1 FROM guild_settings WHERE guild_id=? AND feature='general'", (gid,)).fetchone():
            continue  # already migrated: never overwrite dashboard changes
        g = schemas.defaults("general")
        g.update(log_channel=str(cfg.get("log_channel") or ""), autorole=str(cfg.get("autorole") or ""),
                 antilink=bool(cfg.get("antilink", False)), antispam=bool(cfg.get("antispam", True)))
        db.save_settings(gid, "general", g)
        w = schemas.defaults("welcome")
        if cfg.get("welcome_channel"):
            w.update(enabled=True, channel=str(cfg["welcome_channel"]), title="👋 عضو جديد!",
                     description="أهلاً {user} في **{server}**\nإنت العضو رقم **{count}**", color="#57f287")
        db.save_settings(gid, "welcome", w)
        n += 1
    return n
