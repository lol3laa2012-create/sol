"""Feature settings: defaults + strict validation. The dashboard can only write what is declared here."""
import re
HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
SNOWFLAKE = re.compile(r"^\d{15,22}$")

def _bool(v): return v if isinstance(v, bool) else str(v).lower() in ("1", "true", "on")
def _str(n): return lambda v: str(v)[:n]
def _hex(v):
    v = str(v)
    if not HEX.match(v): raise ValueError("bad color")
    return v
def _id(v):
    v = "" if v in (None, "", "0") else str(v)
    if v and not SNOWFLAKE.match(v): raise ValueError("bad id")
    return v
def _url(v):
    v = str(v).strip()
    if v and not re.match(r"^https://[^\s]{3,500}$", v): raise ValueError("url must be https")
    return v
def _lang(v):
    if v not in ("ar", "en"): raise ValueError("lang")
    return v

FEATURES = {
  "welcome": {"enabled": (False, _bool), "channel": ("", _id), "title": ("👋 Welcome!", _str(256)),
              "description": ("Welcome {user} to **{server}** — you are member #{count}", _str(2000)),
              "color": ("#7c5cff", _hex), "image_url": ("", _url), "show_avatar": (True, _bool),
              "show_count": (True, _bool), "button_label": ("", _str(80)), "button_url": ("", _url)},
  "goodbye": {"enabled": (False, _bool), "channel": ("", _id), "title": ("👋 Goodbye", _str(256)),
              "description": ("**{username}** left **{server}**", _str(2000)),
              "color": ("#c0c0c8", _hex), "image_url": ("", _url), "show_avatar": (True, _bool)},
  "general": {"language": ("ar", _lang), "log_channel": ("", _id), "autorole": ("", _id),
              "antilink": (False, _bool), "antispam": (True, _bool)},
}

def defaults(feature): return {k: v[0] for k, v in FEATURES[feature].items()}

def validate(feature, payload):
    """Returns (clean, errors). Unknown keys are rejected, never stored."""
    spec, clean, errs = FEATURES[feature], {}, {}
    for k, v in payload.items():
        if k not in spec: errs[k] = "unknown field"; continue
        try: clean[k] = spec[k][1](v)
        except Exception: errs[k] = "invalid value"
    return clean, errs
