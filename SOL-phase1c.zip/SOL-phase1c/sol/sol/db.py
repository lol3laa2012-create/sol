"""SOL shared database (SQLite, WAL). Used by BOTH the bot and the dashboard.
Every row is keyed by guild_id so servers can never affect each other."""
import json, os, sqlite3, threading, time

DATA_DIR = os.getenv("DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "data"))
DB_PATH = os.getenv("SOL_DB", os.path.join(DATA_DIR, "sol.db"))
_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS guild_settings(
  guild_id TEXT NOT NULL, feature TEXT NOT NULL, data TEXT NOT NULL,
  updated REAL NOT NULL, PRIMARY KEY(guild_id, feature));
CREATE TABLE IF NOT EXISTS guilds(
  guild_id TEXT PRIMARY KEY, name TEXT, icon TEXT, member_count INTEGER DEFAULT 0,
  channels TEXT DEFAULT '[]', roles TEXT DEFAULT '[]', present INTEGER DEFAULT 1, updated REAL);
CREATE TABLE IF NOT EXISTS bot_status(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS command_queue(
  id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT, action TEXT NOT NULL,
  payload TEXT DEFAULT '{}', status TEXT DEFAULT 'pending', created REAL, done REAL, result TEXT);
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT, kind TEXT, text TEXT, ts REAL);
CREATE INDEX IF NOT EXISTS idx_act ON activity(guild_id, ts);
"""

def conn():
    c = getattr(_local, "c", None)
    if c is None or getattr(_local, "path", None) != DB_PATH:
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        c = sqlite3.connect(DB_PATH, timeout=15, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(SCHEMA)
        _local.c, _local.path = c, DB_PATH
    return c

def get_settings(gid, feature, defaults):
    r = conn().execute("SELECT data FROM guild_settings WHERE guild_id=? AND feature=?", (str(gid), feature)).fetchone()
    out = dict(defaults)
    if r:
        out.update(json.loads(r["data"]))
    return out

def save_settings(gid, feature, data):
    conn().execute("INSERT INTO guild_settings VALUES(?,?,?,?) ON CONFLICT(guild_id,feature) "
                   "DO UPDATE SET data=excluded.data, updated=excluded.updated",
                   (str(gid), feature, json.dumps(data, ensure_ascii=False), time.time()))

def upsert_guild(gid, name, icon, member_count, channels, roles, present=1):
    conn().execute("INSERT INTO guilds VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(guild_id) DO UPDATE SET "
                   "name=excluded.name, icon=excluded.icon, member_count=excluded.member_count, "
                   "channels=excluded.channels, roles=excluded.roles, present=excluded.present, updated=excluded.updated",
                   (str(gid), name, icon, member_count, json.dumps(channels), json.dumps(roles), present, time.time()))

def get_guild(gid):
    r = conn().execute("SELECT * FROM guilds WHERE guild_id=? AND present=1", (str(gid),)).fetchone()
    if not r: return None
    d = dict(r); d["channels"] = json.loads(d["channels"]); d["roles"] = json.loads(d["roles"]); return d

def present_guild_ids():
    return {r["guild_id"] for r in conn().execute("SELECT guild_id FROM guilds WHERE present=1")}

def all_guilds():
    return [dict(r) for r in conn().execute("SELECT guild_id,name,icon,member_count,updated FROM guilds WHERE present=1 ORDER BY name")]

def set_status(k, v): conn().execute("INSERT INTO bot_status VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))
def get_status(): return {r["k"]: r["v"] for r in conn().execute("SELECT * FROM bot_status")}

def log_activity(gid, kind, text):
    conn().execute("INSERT INTO activity(guild_id,kind,text,ts) VALUES(?,?,?,?)", (str(gid), kind, text[:300], time.time()))

def recent_activity(gid, n=15):
    return [dict(r) for r in conn().execute("SELECT kind,text,ts FROM activity WHERE guild_id=? ORDER BY ts DESC LIMIT ?", (str(gid), n))]

def enqueue(gid, action, payload=None):
    cur = conn().execute("INSERT INTO command_queue(guild_id,action,payload,created) VALUES(?,?,?,?)",
                         (str(gid) if gid else None, action, json.dumps(payload or {}), time.time()))
    return cur.lastrowid

def pending_commands():
    return [dict(r) for r in conn().execute("SELECT * FROM command_queue WHERE status=\"pending\" ORDER BY id LIMIT 20")]

def finish_command(cid, ok, result=""):
    conn().execute("UPDATE command_queue SET status=?, done=?, result=? WHERE id=?", ("done" if ok else "error", time.time(), result[:300], cid))
