import re, hmac, os, secrets, time, functools
from collections import defaultdict, deque
from flask import send_from_directory, Flask, abort, jsonify, redirect, render_template, request, session, url_for, make_response
from sol import db, schemas
from dashboard import discord_api as dapi
from dashboard.i18n import T

ADMIN, MANAGE_GUILD = 0x8, 0x20

def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(32)
    if not os.environ.get("SECRET_KEY"):
        app.logger.warning("SECRET_KEY not set: sessions reset on restart. Set it in .env")
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                      SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
                      PERMANENT_SESSION_LIFETIME=7 * 86400, MAX_CONTENT_LENGTH=9 * 1024 * 1024)
    hits = defaultdict(lambda: deque())

    def limited(key, n, per):
        q, now = hits[key], time.time()
        while q and now - q[0] > per: q.popleft()
        if len(q) >= n: return True
        q.append(now); return False

    @app.before_request
    def guard():
        ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
        if limited((ip, request.method == "POST"), 20 if request.method == "POST" else 120, 60): abort(429)
        if request.method == "POST" and request.path.startswith("/api/"):
            tok = request.headers.get("X-CSRF", "")
            if not session.get("csrf") or not hmac.compare_digest(tok, session["csrf"]): abort(403)

    def lang():
        l = request.args.get("lang") or request.cookies.get("lang") or "ar"
        return l if l in T else "ar"

    @app.after_request
    def headers(r):
        r.headers["X-Content-Type-Options"] = "nosniff"; r.headers["X-Frame-Options"] = "DENY"
        r.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"
        if request.args.get("lang") in T: r.set_cookie("lang", request.args["lang"], max_age=31536000, samesite="Lax")
        return r

    @app.context_processor
    def ctx():
        return {"t": T[lang()], "lang": lang(), "user": session.get("user"), "csrf": session.get("csrf", "")}

    def login_required(f):
        @functools.wraps(f)
        def w(*a, **k):
            if "user" not in session: return redirect(url_for("index"))
            return f(*a, **k)
        return w

    def can_manage(gid):
        """Server-side check against the guild list captured at login. Never trusts client input."""
        for g in session.get("guilds", []):
            if g["id"] == str(gid):
                return g.get("owner") or int(g.get("permissions", 0)) & (ADMIN | MANAGE_GUILD) > 0
        return False

    def guild_or_403(gid):
        if not can_manage(gid): abort(403)
        g = db.get_guild(gid)
        if not g: abort(404)
        return g

    @app.get("/")
    def index():
        if "user" in session: return redirect(url_for("servers"))
        return render_template("index.html")

    @app.get("/login")
    def login():
        session["state"] = secrets.token_urlsafe(24)
        return redirect(dapi.authorize_url(session["state"]))

    @app.get("/callback")
    def callback():
        if not request.args.get("code") or not hmac.compare_digest(request.args.get("state", ""), session.get("state", "x")): abort(400)
        try:
            tok = dapi.exchange_code(request.args["code"])
            u, gl = dapi.fetch_user(tok), dapi.fetch_guilds(tok)
        except Exception:
            app.logger.exception("oauth failed"); abort(502)
        session.clear(); session.permanent = True
        session["user"] = {"id": u["id"], "name": u.get("global_name") or u["username"], "avatar": u.get("avatar")}
        session["guilds"] = [{"id": g["id"], "name": g["name"], "icon": g.get("icon"), "owner": g.get("owner", False),
                              "permissions": int(g.get("permissions", 0))} for g in gl]
        session["csrf"] = secrets.token_urlsafe(24)
        return redirect(url_for("servers"))

    @app.get("/logout")
    def logout():
        session.clear(); return redirect(url_for("index"))

    @app.get("/servers")
    @login_required
    def servers():
        present = db.present_guild_ids()
        mine = [g for g in session["guilds"] if can_manage(g["id"])]
        for g in mine: g["has_bot"] = g["id"] in present
        return render_template("servers.html", guilds=mine, invite=dapi.invite_url())

    @app.get("/g/<gid>")
    @login_required
    def overview(gid):
        g = guild_or_403(gid); st = db.get_status()
        online = time.time() - float(st.get("heartbeat", 0)) < 90
        up = int(time.time() - float(st.get("started", time.time()))) if online else 0
        feats = {f: db.get_settings(gid, f, schemas.defaults(f)).get("enabled") for f in ("welcome", "goodbye")}
        return render_template("overview.html", g=g, online=online, uptime=up, feats=feats,
                               total_guilds=len(db.present_guild_ids()), activity=db.recent_activity(gid), page="overview")

    @app.get("/g/<gid>/<feature>")
    @login_required
    def feature_page(gid, feature):
        g = guild_or_403(gid)
        if feature not in schemas.FEATURES: abort(404)
        cfg = db.get_settings(gid, feature, schemas.defaults(feature))
        chans = [c for c in g["channels"] if c.get("type") == "text"]
        roles = [r for r in g["roles"] if not r.get("managed") and r["name"] != "@everyone"]
        return render_template("feature.html", g=g, feature=feature, cfg=cfg, spec=schemas.FEATURES[feature],
                               chans=chans, roles=roles, page=feature)

    @app.get("/api/g/<gid>/settings/<feature>")
    @login_required
    def api_get(gid, feature):
        guild_or_403(gid)
        if feature not in schemas.FEATURES: abort(404)
        return jsonify(db.get_settings(gid, feature, schemas.defaults(feature)))

    @app.post("/api/g/<gid>/settings/<feature>")
    @login_required
    def api_save(gid, feature):
        g = guild_or_403(gid)
        if feature not in schemas.FEATURES: abort(404)
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict): abort(400)
        clean, errs = schemas.validate(feature, payload)
        if errs: return jsonify(ok=False, errors=errs), 400
        # channel/role ids must belong to THIS guild
        ids = {c["id"] for c in g["channels"]} | {r["id"] for r in g["roles"]}
        for k, v in clean.items():
            if k in ("channel", "log_channel", "autorole") and v and v not in ids:
                return jsonify(ok=False, errors={k: "not in this server"}), 400
        cur = db.get_settings(gid, feature, schemas.defaults(feature)); cur.update(clean)
        db.save_settings(gid, feature, cur)
        db.log_activity(gid, "settings", f"{session['user']['name']} updated {feature}")
        return jsonify(ok=True, settings=cur)

    @app.post("/api/g/<gid>/test/<feature>")
    @login_required
    def api_test(gid, feature):
        guild_or_403(gid)
        if feature not in ("welcome", "goodbye"): abort(404)
        cid = db.enqueue(gid, f"test_{feature}", {"user_id": session["user"]["id"]})
        return jsonify(ok=True, queued=cid)

    MEDIA = os.path.join(db.DATA_DIR, "uploads")
    SIGS = ((b"GIF87a", ".gif"), (b"GIF89a", ".gif"), (b"\x89PNG\r\n\x1a\n", ".png"), (b"\xff\xd8\xff", ".jpg"))

    def sniff(b):
        for sig, ext in SIGS:
            if b.startswith(sig): return ext
        if b[:4] == b"RIFF" and b[8:12] == b"WEBP": return ".webp"
        return None

    @app.post("/api/g/<gid>/upload")
    @login_required
    def api_upload(gid):
        guild_or_403(gid)
        f = request.files.get("file")
        if not f: abort(400)
        data = f.read(8 * 1024 * 1024 + 1)
        if len(data) > 8 * 1024 * 1024: return jsonify(ok=False, error="max 8MB"), 413
        ext = sniff(data)                      # real content check, the filename is ignored
        if not ext: return jsonify(ok=False, error="only GIF/PNG/JPG/WEBP"), 400
        d = os.path.join(MEDIA, str(int(gid))); os.makedirs(d, exist_ok=True)
        if sum(os.path.getsize(os.path.join(d, x)) for x in os.listdir(d)) + len(data) > 100 * 1024 * 1024:
            return jsonify(ok=False, error="server storage full (100MB)"), 413
        name = secrets.token_hex(12) + ext
        with open(os.path.join(d, name), "wb") as o: o.write(data)   # bytes untouched => GIF stays animated
        base = os.environ.get("BASE_URL", request.host_url).rstrip("/")
        db.log_activity(gid, "upload", f"{session['user']['name']} uploaded {name}")
        return jsonify(ok=True, url=f"{base}/media/{int(gid)}/{name}")

    @app.get("/media/<int:gid>/<name>")
    def media(gid, name):
        if not re.fullmatch(r"[0-9a-f]{24}\.(gif|png|jpg|webp)", name): abort(404)
        r = send_from_directory(os.path.join(MEDIA, str(gid)), name, max_age=86400)
        r.headers["Content-Disposition"] = "inline"; return r

    @app.get("/healthz")
    def healthz(): return "ok"
    return app

app = create_app()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
