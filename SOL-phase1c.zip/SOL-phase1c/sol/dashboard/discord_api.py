"""Thin Discord OAuth2 client. Isolated so tests can replace it."""
import json, os, urllib.parse, urllib.request
API = "https://discord.com/api/v10"
def _cfg(): return os.environ["DISCORD_CLIENT_ID"], os.environ["DISCORD_CLIENT_SECRET"], os.environ["DISCORD_REDIRECT_URI"]

def authorize_url(state):
    cid, _, redirect = _cfg()
    return f"{API}/oauth2/authorize?" + urllib.parse.urlencode({"client_id": cid, "redirect_uri": redirect,
            "response_type": "code", "scope": "identify guilds", "state": state, "prompt": "none"})

def invite_url():
    cid = os.environ.get("DISCORD_CLIENT_ID", "")
    return f"{API}/oauth2/authorize?" + urllib.parse.urlencode({"client_id": cid, "permissions": 8, "scope": "bot applications.commands"})

def _req(url, data=None, token=None):
    h = {"User-Agent": "SOL-Dashboard (1.0)"}
    if token: h["Authorization"] = f"Bearer {token}"
    if data is not None:
        data = urllib.parse.urlencode(data).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    with urllib.request.urlopen(urllib.request.Request(url, data=data, headers=h), timeout=10) as r:
        return json.loads(r.read())

def exchange_code(code):
    cid, secret, redirect = _cfg()
    return _req(f"{API}/oauth2/token", {"client_id": cid, "client_secret": secret, "grant_type": "authorization_code",
                                         "code": code, "redirect_uri": redirect})["access_token"]
def fetch_user(token): return _req(f"{API}/users/@me", token=token)
def fetch_guilds(token): return _req(f"{API}/users/@me/guilds", token=token)
