"""Start SOL: dashboard + bot together (default) or separately: `python run.py bot` / `python run.py web`."""
import os, sys, threading
from dotenv import load_dotenv
load_dotenv()

def web(block=True):
    from dashboard.app import app
    port = int(os.environ.get("PORT", 8080))
    try:
        from waitress import serve
        serve(app, host="0.0.0.0", port=port, threads=8)
    except ImportError:
        app.run(host="0.0.0.0", port=port)

def bot():
    import bot as b
    if not b.TOKEN: raise SystemExit("DISCORD_TOKEN missing in .env")
    b.bot.run(b.TOKEN)

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode == "web": web()
    elif mode == "bot": bot()
    else:
        threading.Thread(target=web, daemon=True).start()
        bot()
