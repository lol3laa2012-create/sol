# تشغيل SOL على Oracle Cloud مجاناً (24 ساعة)

## 1) أنشئ حساب وسيرفر
1. سجّل في oracle.com/cloud/free (ممكن يطلب كارت للتحقق فقط، ولا يخصم لو استخدمت موارد Always Free).
2. Compute → Instances → Create instance.
3. Image: **Ubuntu 22.04**. Shape: **Ampere (VM.Standard.A1.Flex)** — اللي عليه علامة Always Free.
4. اضغط Download private key واحفظ الملف (مهم جداً). Create.
5. انسخ **Public IP** بتاع السيرفر.

## 2) افتح البورتات في Oracle
Networking → Virtual Cloud Networks → الشبكة بتاعتك → Security Lists → Default → Add Ingress Rules:
- Source CIDR: `0.0.0.0/0` ، Protocol TCP ، Destination Port: `80` ثم أضف قاعدة تانية للبورت `443`.

## 3) اسم دومين مجاني
1. ادخل duckdns.org وسجّل بحساب جوجل.
2. اكتب اسم (مثلاً `mysol`) → Add domain → في خانة current ip حط الـ Public IP → update.
3. دومينك هيكون `mysol.duckdns.org`.

## 4) ارفع الملفات وشغّلها (من PowerShell على ويندوز)
```
scp -i مسار_المفتاح.key SOL-phase1c.zip ubuntu@PUBLIC_IP:~
ssh -i مسار_المفتاح.key ubuntu@PUBLIC_IP
sudo apt-get install -y unzip && unzip SOL-phase1c.zip && cd sol
bash deploy/oracle_install.sh mysol.duckdns.org
```
السكربت هيسألك عن: التوكن، Client ID، Client Secret، وهيكتب `.env` بنفسه، ويركّب HTTPS والتشغيل التلقائي.

## 5) إعدادات ديسكورد
في Developer Portal → OAuth2 → Redirects ضيف: `https://mysol.duckdns.org/callback` واضغط Save. وفعّل الـ Intents الثلاثة في صفحة Bot.

## أوامر مفيدة
- متابعة الأخطاء: `journalctl -u sol -f`
- إعادة تشغيل: `sudo systemctl restart sol`
- تحديث الملفات: ارفع الـ zip الجديد وفكه فوق المجلد (ملف `.env` ومجلد `data` متتمسحوش) ثم restart.
- ملاحظة: خد نسخة من مجلد `data` من وقت لوقت (فيه الإعدادات والصور).
